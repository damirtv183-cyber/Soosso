package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.IslandAccent
import com.example.data.model.IslandAnimStyle
import com.example.data.repository.SettingsRepository
import com.example.data.repository.ToolsManager
import com.example.service.TiraOverlayService
import com.example.ui.util.formatDurationMs
import com.example.ui.util.formatSpeedBytesPerSec
import com.example.ui.util.formatStopwatchMs
import com.example.ui.util.formatTimerSeconds
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowSettings

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class TiraLogicTest {

    @Test
    fun `calculator computes arithmetic and handles division by zero`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val tools = ToolsManager(context)

        "12+8×2=".forEach { tools.onCalcKey(it.toString()) }
        assertEquals("28", tools.toolsState.value.calculator.display)
        assertNull(tools.toolsState.value.calculator.error)

        tools.onCalcKey("C")
        "5÷0=".forEach { tools.onCalcKey(it.toString()) }
        assertNotNull(tools.toolsState.value.calculator.error)
    }

    @Test
    fun `format helpers produce expected Russian and tabular strings`() {
        assertEquals("1:05", formatDurationMs(65_000L))
        assertEquals("05:00", formatTimerSeconds(300))
        assertEquals("01:02.50", formatStopwatchMs(62_500L))
        assertEquals("512 Б/с", formatSpeedBytesPerSec(512L))
        assertEquals("2.0 КБ/с", formatSpeedBytesPerSec(2048L))
    }

    @Test
    fun `settings repository persists up to 8 pinned apps and appearance`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = SettingsRepository(context)

        val pkgs = (1..10).map { "com.test.app$it" }
        repo.setPinnedPackages(pkgs)
        repo.updateSettings {
            it.copy(
                accent = IslandAccent.SILVER,
                animStyle = IslandAnimStyle.SNAPPY,
                collapsedWidthDp = 188,
                topOffsetDp = 24,
            )
        }

        val loaded = repo.settingsFlow.first()
        assertEquals(8, loaded.pinnedPackages.size)
        assertEquals(IslandAccent.SILVER, loaded.accent)
        assertEquals(IslandAnimStyle.SNAPPY, loaded.animStyle)
        assertEquals(188, loaded.collapsedWidthDp)
        assertEquals(24, loaded.topOffsetDp)
    }

    @Test
    fun `overlay service attaches view when overlay permission is granted`() {
        ShadowSettings.setCanDrawOverlays(true)
        val controller = Robolectric.buildService(TiraOverlayService::class.java)
            .create()
            .startCommand(0, 0)
        assertTrue(TiraOverlayService.isRunning.value)
        assertTrue(TiraOverlayService.isOverlayAttached.value)
        assertNull(TiraOverlayService.lastError.value)
        controller.destroy()
    }
}
