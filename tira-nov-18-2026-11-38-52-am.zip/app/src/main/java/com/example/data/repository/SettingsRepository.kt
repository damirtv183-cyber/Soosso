package com.example.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.IslandAccent
import com.example.data.model.IslandAnimStyle
import com.example.data.model.IslandSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.tiraDataStore: DataStore<Preferences> by preferencesDataStore(name = "tira_settings")

class SettingsRepository(private val context: Context) {

    private object Keys {
        val OVERLAY_ENABLED = booleanPreferencesKey("overlay_enabled")
        val ACCENT = stringPreferencesKey("accent")
        val CAPSULE_OPACITY = floatPreferencesKey("capsule_opacity")
        val GLOW_BORDER = booleanPreferencesKey("glow_border")
        val SHOW_IDLE_CLOCK = booleanPreferencesKey("show_idle_clock")
        val ANIM_STYLE = stringPreferencesKey("anim_style")
        val ANIM_SPEED = floatPreferencesKey("anim_speed")
        val EQUALIZER_PULSE = booleanPreferencesKey("equalizer_pulse")
        val COLLAPSED_WIDTH_DP = intPreferencesKey("collapsed_width_dp")
        val COLLAPSED_HEIGHT_DP = intPreferencesKey("collapsed_height_dp")
        val CORNER_RADIUS_DP = intPreferencesKey("corner_radius_dp")
        val EXPANDED_WIDTH_DP = intPreferencesKey("expanded_width_dp")
        val TOP_OFFSET_DP = intPreferencesKey("top_offset_dp")
        val HORIZONTAL_OFFSET_DP = intPreferencesKey("horizontal_offset_dp")
        val AUTO_COLLAPSE_SECONDS = intPreferencesKey("auto_collapse_seconds")
        val GAME_TURBO_ACTIVE = booleanPreferencesKey("game_turbo_active")
        val GAME_TURBO_DND = booleanPreferencesKey("game_turbo_dnd")
        val GAME_TURBO_KEEP_SCREEN_ON = booleanPreferencesKey("game_turbo_keep_screen_on")
        val GAME_TURBO_COMPACT_HUD = booleanPreferencesKey("game_turbo_compact_hud")
        val PINNED_PACKAGES = stringPreferencesKey("pinned_packages")
        val HAS_CUSTOMIZED_PINNED = booleanPreferencesKey("has_customized_pinned")
    }

    val settingsFlow: Flow<IslandSettings> = context.tiraDataStore.data
        .catch { exception ->
            if (exception is IOException) {
                emit(androidx.datastore.preferences.core.emptyPreferences())
            } else {
                throw exception
            }
        }
        .map { prefs ->
            val accentName = prefs[Keys.ACCENT] ?: IslandAccent.PURE_WHITE.name
            val animName = prefs[Keys.ANIM_STYLE] ?: IslandAnimStyle.SPRING.name
            val rawPinned = prefs[Keys.PINNED_PACKAGES].orEmpty()
            val pinnedList = if (rawPinned.isBlank()) {
                emptyList()
            } else {
                rawPinned.split("|").filter { it.isNotBlank() }.distinct().take(MAX_PINNED_APPS)
            }

            IslandSettings(
                isOverlayEnabled = prefs[Keys.OVERLAY_ENABLED] ?: false,
                accent = runCatching { IslandAccent.valueOf(accentName) }.getOrDefault(IslandAccent.PURE_WHITE),
                capsuleOpacity = (prefs[Keys.CAPSULE_OPACITY] ?: 0.96f).coerceIn(0.65f, 1.0f),
                glowBorderEnabled = prefs[Keys.GLOW_BORDER] ?: true,
                showIdleClock = prefs[Keys.SHOW_IDLE_CLOCK] ?: true,
                animStyle = runCatching { IslandAnimStyle.valueOf(animName) }.getOrDefault(IslandAnimStyle.SPRING),
                animSpeedMultiplier = (prefs[Keys.ANIM_SPEED] ?: 1.0f).coerceIn(0.6f, 1.6f),
                equalizerPulseEnabled = prefs[Keys.EQUALIZER_PULSE] ?: true,
                collapsedWidthDp = (prefs[Keys.COLLAPSED_WIDTH_DP] ?: 156).coerceIn(112, 260),
                collapsedHeightDp = (prefs[Keys.COLLAPSED_HEIGHT_DP] ?: 34).coerceIn(26, 48),
                cornerRadiusDp = (prefs[Keys.CORNER_RADIUS_DP] ?: 24).coerceIn(12, 32),
                expandedWidthDp = (prefs[Keys.EXPANDED_WIDTH_DP] ?: 368).coerceIn(300, 440),
                topOffsetDp = (prefs[Keys.TOP_OFFSET_DP] ?: 16).coerceIn(0, 96),
                horizontalOffsetDp = (prefs[Keys.HORIZONTAL_OFFSET_DP] ?: 0).coerceIn(-120, 120),
                autoCollapseSeconds = (prefs[Keys.AUTO_COLLAPSE_SECONDS] ?: 15).coerceIn(0, 60),
                gameTurboActive = prefs[Keys.GAME_TURBO_ACTIVE] ?: false,
                gameTurboDnd = prefs[Keys.GAME_TURBO_DND] ?: true,
                gameTurboKeepScreenOn = prefs[Keys.GAME_TURBO_KEEP_SCREEN_ON] ?: true,
                gameTurboCompactHud = prefs[Keys.GAME_TURBO_COMPACT_HUD] ?: true,
                pinnedPackages = pinnedList,
                hasCustomizedPinnedApps = prefs[Keys.HAS_CUSTOMIZED_PINNED] ?: false,
            )
        }

    suspend fun updateSettings(transform: (IslandSettings) -> IslandSettings) {
        context.tiraDataStore.edit { prefs ->
            val current = IslandSettings(
                isOverlayEnabled = prefs[Keys.OVERLAY_ENABLED] ?: false,
                accent = runCatching {
                    IslandAccent.valueOf(prefs[Keys.ACCENT] ?: IslandAccent.PURE_WHITE.name)
                }.getOrDefault(IslandAccent.PURE_WHITE),
                capsuleOpacity = prefs[Keys.CAPSULE_OPACITY] ?: 0.96f,
                glowBorderEnabled = prefs[Keys.GLOW_BORDER] ?: true,
                showIdleClock = prefs[Keys.SHOW_IDLE_CLOCK] ?: true,
                animStyle = runCatching {
                    IslandAnimStyle.valueOf(prefs[Keys.ANIM_STYLE] ?: IslandAnimStyle.SPRING.name)
                }.getOrDefault(IslandAnimStyle.SPRING),
                animSpeedMultiplier = prefs[Keys.ANIM_SPEED] ?: 1.0f,
                equalizerPulseEnabled = prefs[Keys.EQUALIZER_PULSE] ?: true,
                collapsedWidthDp = prefs[Keys.COLLAPSED_WIDTH_DP] ?: 156,
                collapsedHeightDp = prefs[Keys.COLLAPSED_HEIGHT_DP] ?: 34,
                cornerRadiusDp = prefs[Keys.CORNER_RADIUS_DP] ?: 24,
                expandedWidthDp = prefs[Keys.EXPANDED_WIDTH_DP] ?: 368,
                topOffsetDp = prefs[Keys.TOP_OFFSET_DP] ?: 10,
                horizontalOffsetDp = prefs[Keys.HORIZONTAL_OFFSET_DP] ?: 0,
                autoCollapseSeconds = prefs[Keys.AUTO_COLLAPSE_SECONDS] ?: 15,
                gameTurboActive = prefs[Keys.GAME_TURBO_ACTIVE] ?: false,
                gameTurboDnd = prefs[Keys.GAME_TURBO_DND] ?: true,
                gameTurboKeepScreenOn = prefs[Keys.GAME_TURBO_KEEP_SCREEN_ON] ?: true,
                gameTurboCompactHud = prefs[Keys.GAME_TURBO_COMPACT_HUD] ?: true,
                pinnedPackages = prefs[Keys.PINNED_PACKAGES].orEmpty()
                    .split("|").filter { it.isNotBlank() }.distinct().take(MAX_PINNED_APPS),
                hasCustomizedPinnedApps = prefs[Keys.HAS_CUSTOMIZED_PINNED] ?: false,
            )
            val updated = transform(current)
            prefs[Keys.OVERLAY_ENABLED] = updated.isOverlayEnabled
            prefs[Keys.ACCENT] = updated.accent.name
            prefs[Keys.CAPSULE_OPACITY] = updated.capsuleOpacity
            prefs[Keys.GLOW_BORDER] = updated.glowBorderEnabled
            prefs[Keys.SHOW_IDLE_CLOCK] = updated.showIdleClock
            prefs[Keys.ANIM_STYLE] = updated.animStyle.name
            prefs[Keys.ANIM_SPEED] = updated.animSpeedMultiplier
            prefs[Keys.EQUALIZER_PULSE] = updated.equalizerPulseEnabled
            prefs[Keys.COLLAPSED_WIDTH_DP] = updated.collapsedWidthDp
            prefs[Keys.COLLAPSED_HEIGHT_DP] = updated.collapsedHeightDp
            prefs[Keys.CORNER_RADIUS_DP] = updated.cornerRadiusDp
            prefs[Keys.EXPANDED_WIDTH_DP] = updated.expandedWidthDp
            prefs[Keys.TOP_OFFSET_DP] = updated.topOffsetDp
            prefs[Keys.HORIZONTAL_OFFSET_DP] = updated.horizontalOffsetDp
            prefs[Keys.AUTO_COLLAPSE_SECONDS] = updated.autoCollapseSeconds
            prefs[Keys.GAME_TURBO_ACTIVE] = updated.gameTurboActive
            prefs[Keys.GAME_TURBO_DND] = updated.gameTurboDnd
            prefs[Keys.GAME_TURBO_KEEP_SCREEN_ON] = updated.gameTurboKeepScreenOn
            prefs[Keys.GAME_TURBO_COMPACT_HUD] = updated.gameTurboCompactHud
            prefs[Keys.PINNED_PACKAGES] = updated.pinnedPackages.distinct().take(MAX_PINNED_APPS).joinToString("|")
            prefs[Keys.HAS_CUSTOMIZED_PINNED] = updated.hasCustomizedPinnedApps
        }
    }

    suspend fun setOverlayEnabled(enabled: Boolean) {
        context.tiraDataStore.edit { prefs ->
            prefs[Keys.OVERLAY_ENABLED] = enabled
        }
    }

    suspend fun seedDefaultPinnedPackagesIfEmpty(packages: List<String>) {
        context.tiraDataStore.edit { prefs ->
            val customized = prefs[Keys.HAS_CUSTOMIZED_PINNED] ?: false
            val existing = prefs[Keys.PINNED_PACKAGES].orEmpty()
            if (!customized && existing.isBlank() && packages.isNotEmpty()) {
                prefs[Keys.PINNED_PACKAGES] = packages.distinct().take(MAX_PINNED_APPS).joinToString("|")
            }
        }
    }

    suspend fun setPinnedPackages(packages: List<String>) {
        context.tiraDataStore.edit { prefs ->
            prefs[Keys.PINNED_PACKAGES] = packages.distinct().take(MAX_PINNED_APPS).joinToString("|")
            prefs[Keys.HAS_CUSTOMIZED_PINNED] = true
        }
    }

    suspend fun resetAppearanceAndLayoutDefaults() {
        val defaults = IslandSettings()
        updateSettings { current ->
            defaults.copy(
                isOverlayEnabled = current.isOverlayEnabled,
                pinnedPackages = current.pinnedPackages,
                hasCustomizedPinnedApps = current.hasCustomizedPinnedApps,
            )
        }
    }

    companion object {
        const val MAX_PINNED_APPS = 8
    }
}
