package com.example.data.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.ui.graphics.vector.ImageVector

enum class IslandSection(
    val titleRu: String,
    val shortTitleRu: String,
    val icon: ImageVector,
) {
    LAUNCHER("Лаунчер", "Прилож.", Icons.Rounded.Apps),
    MUSIC("Музыка", "Музыка", Icons.Rounded.MusicNote),
    BATTERY("Батарея", "Заряд", Icons.Rounded.BatteryChargingFull),
    SYSTEM("Система", "Система", Icons.Rounded.Memory),
    GAMING("Игры", "Turbo", Icons.Rounded.SportsEsports),
    NETWORK("Сеть", "Сеть", Icons.Rounded.Wifi),
    TOOLS("Инструменты", "Утилиты", Icons.Rounded.Build),
    SETTINGS("Настройки", "Вид", Icons.Rounded.Settings),
}
