package com.example.data.model

import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import com.example.ui.theme.FrostWhite
import com.example.ui.theme.PlatinumSilver
import com.example.ui.theme.PureWhite
import com.example.ui.theme.TitaniumGrey
import com.example.ui.theme.WarmIvory

enum class IslandAccent(
    val titleRu: String,
    val primaryColor: Color,
    val secondaryColor: Color,
) {
    PURE_WHITE("Белый", PureWhite, PlatinumSilver),
    SILVER("Серебро", PlatinumSilver, TitaniumGrey),
    TITANIUM("Титан", TitaniumGrey, Color(0xFF757D8A)),
    FROST("Лёд", FrostWhite, Color(0xFF9EA6B2)),
    IVORY("Жемчуг", WarmIvory, Color(0xFFA8A095)),
}

enum class IslandAnimStyle(
    val titleRu: String,
    val stiffness: Float,
    val dampingRatio: Float,
) {
    SPRING("Пружина", 340f, 0.90f),
    SMOOTH("Плавная", 220f, 1.00f),
    SNAPPY("Быстрая", 520f, 0.95f),
}

@Immutable
data class IslandSettings(
    val isOverlayEnabled: Boolean = false,
    val accent: IslandAccent = IslandAccent.PURE_WHITE,
    val capsuleOpacity: Float = 0.97f,
    val glowBorderEnabled: Boolean = true,
    val showIdleClock: Boolean = true,
    val animStyle: IslandAnimStyle = IslandAnimStyle.SPRING,
    val animSpeedMultiplier: Float = 1.0f,
    val equalizerPulseEnabled: Boolean = true,
    val collapsedWidthDp: Int = 156,
    val collapsedHeightDp: Int = 34,
    val cornerRadiusDp: Int = 24,
    val expandedWidthDp: Int = 368,
    val topOffsetDp: Int = 16,
    val horizontalOffsetDp: Int = 0,
    val autoCollapseSeconds: Int = 15,
    val gameTurboActive: Boolean = false,
    val gameTurboDnd: Boolean = true,
    val gameTurboKeepScreenOn: Boolean = true,
    val gameTurboCompactHud: Boolean = true,
    val pinnedPackages: List<String> = emptyList(),
    val hasCustomizedPinnedApps: Boolean = false,
)
