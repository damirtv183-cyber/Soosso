package com.example.data.model

import android.graphics.Bitmap
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.ImageBitmap

@Immutable
data class InstalledAppInfo(
    val packageName: String,
    val label: String,
    val icon: ImageBitmap?,
    val isGame: Boolean,
)

@Immutable
data class MusicState(
    val hasActiveSession: Boolean = false,
    val title: String = "Нет активного трека",
    val artist: String = "Запустите любой плеер",
    val album: String = "",
    val sourceAppName: String = "",
    val packageName: String = "",
    val albumArt: Bitmap? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val listenerConnected: Boolean = false,
)

@Immutable
data class NotificationBanner(
    val appName: String,
    val title: String,
    val text: String,
    val timestampMs: Long,
)

@Immutable
data class BatteryState(
    val levelPercent: Int = 0,
    val isCharging: Boolean = false,
    val chargeSourceRu: String = "От батареи",
    val statusRu: String = "Неизвестно",
    val temperatureC: Float = 0f,
    val voltageV: Float = 0f,
    val currentMa: Int = 0,
    val healthRu: String = "Норма",
    val technology: String = "Li-ion",
)

@Immutable
data class SystemState(
    val batteryTempC: Float = 0f,
    val thermalStatusRu: String = "Норма",
    val availableRamMb: Long = 0L,
    val totalRamMb: Long = 0L,
    val ramUsagePercent: Int = 0,
    val isLowMemory: Boolean = false,
    val availableStorageGb: Float = 0f,
    val totalStorageGb: Float = 0f,
    val cpuCores: Int = 0,
    val uptimeFormatted: String = "0м",
    val appCacheKb: Long = 0L,
)

@Immutable
data class NetworkState(
    val isConnected: Boolean = false,
    val transportTypeRu: String = "Нет сети",
    val isWifi: Boolean = false,
    val isCellular: Boolean = false,
    val networkName: String = "Автономно",
    val signalBars: Int = 0,
    val linkSpeedMbps: Int = 0,
    val rxBytesPerSec: Long = 0L,
    val txBytesPerSec: Long = 0L,
    val speedHistoryRxKbps: List<Float> = emptyList(),
)

@Immutable
data class TimerState(
    val totalSeconds: Int = 300,
    val remainingSeconds: Int = 300,
    val isRunning: Boolean = false,
    val isFinished: Boolean = false,
)

@Immutable
data class StopwatchState(
    val elapsedMs: Long = 0L,
    val isRunning: Boolean = false,
    val lapsMs: List<Long> = emptyList(),
)

@Immutable
data class FlashlightState(
    val isAvailable: Boolean = true,
    val isOn: Boolean = false,
    val errorMessage: String? = null,
)

@Immutable
data class CalculatorState(
    val expression: String = "",
    val display: String = "0",
    val error: String? = null,
)

@Immutable
data class ToolsState(
    val timer: TimerState = TimerState(),
    val stopwatch: StopwatchState = StopwatchState(),
    val flashlight: FlashlightState = FlashlightState(),
    val calculator: CalculatorState = CalculatorState(),
)

@Immutable
data class PermissionStatus(
    val canDrawOverlays: Boolean = false,
    val isNotificationListenerEnabled: Boolean = false,
    val isPostNotificationsGranted: Boolean = true,
    val isDndPolicyGranted: Boolean = false,
)
