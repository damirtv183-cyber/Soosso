package com.example.data.repository

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import com.example.data.model.CalculatorState
import com.example.data.model.FlashlightState
import com.example.data.model.StopwatchState
import com.example.data.model.TimerState
import com.example.data.model.ToolsState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs

class ToolsManager(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val _toolsState = MutableStateFlow(ToolsState())
    val toolsState: StateFlow<ToolsState> = _toolsState.asStateFlow()

    private var timerJob: Job? = null
    private var stopwatchJob: Job? = null
    private var stopwatchBaseMs: Long = 0L
    private var stopwatchAccumulatedMs: Long = 0L

    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private var torchCameraId: String? = null

    private val torchCallback = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            if (cameraId == torchCameraId) {
                _toolsState.update {
                    it.copy(flashlight = it.flashlight.copy(isOn = enabled, errorMessage = null))
                }
            }
        }

        override fun onTorchModeUnavailable(cameraId: String) {
            if (cameraId == torchCameraId) {
                _toolsState.update {
                    it.copy(flashlight = it.flashlight.copy(isOn = false))
                }
            }
        }
    }

    init {
        initFlashlight()
    }

    private fun initFlashlight() {
        runCatching {
            val foundId = cameraManager.cameraIdList.firstOrNull { id ->
                val chars = cameraManager.getCameraCharacteristics(id)
                val hasFlash = chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                val facing = chars.get(CameraCharacteristics.LENS_FACING)
                hasFlash && facing == CameraCharacteristics.LENS_FACING_BACK
            } ?: cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }

            torchCameraId = foundId
            _toolsState.update {
                it.copy(
                    flashlight = FlashlightState(
                        isAvailable = foundId != null,
                        isOn = false,
                        errorMessage = if (foundId == null) "Вспышка не найдена на устройстве" else null,
                    )
                )
            }
            if (foundId != null) {
                cameraManager.registerTorchCallback(torchCallback, null)
            }
        }.onFailure {
            _toolsState.update {
                it.copy(
                    flashlight = FlashlightState(
                        isAvailable = false,
                        isOn = false,
                        errorMessage = "Не удалось получить доступ к камере для фонарика",
                    )
                )
            }
        }
    }

    fun toggleFlashlight() {
        val id = torchCameraId
        if (id == null) {
            _toolsState.update {
                it.copy(
                    flashlight = it.flashlight.copy(
                        isAvailable = false,
                        errorMessage = "Фонарик недоступен на этом устройстве",
                    )
                )
            }
            return
        }
        val next = !_toolsState.value.flashlight.isOn
        runCatching {
            cameraManager.setTorchMode(id, next)
            _toolsState.update {
                it.copy(flashlight = it.flashlight.copy(isOn = next, errorMessage = null))
            }
        }.onFailure { error ->
            _toolsState.update {
                it.copy(
                    flashlight = it.flashlight.copy(
                        isOn = false,
                        errorMessage = "Ошибка вспышки: ${error.localizedMessage ?: "недоступно"}",
                    )
                )
            }
        }
    }

    // --- Timer ---
    fun setTimerPreset(seconds: Int) {
        timerJob?.cancel()
        val safeSec = seconds.coerceIn(5, 36000)
        _toolsState.update {
            it.copy(
                timer = TimerState(
                    totalSeconds = safeSec,
                    remainingSeconds = safeSec,
                    isRunning = false,
                    isFinished = false,
                )
            )
        }
    }

    fun addTimerSeconds(deltaSeconds: Int) {
        _toolsState.update { current ->
            val t = current.timer
            val nextRem = (t.remainingSeconds + deltaSeconds).coerceIn(5, 36000)
            val nextTotal = maxOf(t.totalSeconds, nextRem)
            current.copy(
                timer = t.copy(
                    totalSeconds = nextTotal,
                    remainingSeconds = nextRem,
                    isFinished = false,
                )
            )
        }
    }

    fun toggleTimer() {
        val t = _toolsState.value.timer
        if (t.isRunning) {
            timerJob?.cancel()
            _toolsState.update { it.copy(timer = it.timer.copy(isRunning = false)) }
        } else {
            val startFrom = if (t.remainingSeconds <= 0) t.totalSeconds else t.remainingSeconds
            _toolsState.update {
                it.copy(
                    timer = it.timer.copy(
                        remainingSeconds = startFrom,
                        isRunning = true,
                        isFinished = false,
                    )
                )
            }
            timerJob?.cancel()
            timerJob = scope.launch {
                while (isActive) {
                    delay(1000L)
                    val cur = _toolsState.value.timer
                    if (!cur.isRunning) break
                    val next = cur.remainingSeconds - 1
                    if (next <= 0) {
                        _toolsState.update {
                            it.copy(
                                timer = cur.copy(
                                    remainingSeconds = 0,
                                    isRunning = false,
                                    isFinished = true,
                                )
                            )
                        }
                        vibrateAlert()
                        break
                    } else {
                        _toolsState.update {
                            it.copy(timer = cur.copy(remainingSeconds = next))
                        }
                    }
                }
            }
        }
    }

    fun resetTimer() {
        timerJob?.cancel()
        _toolsState.update { current ->
            current.copy(
                timer = current.timer.copy(
                    remainingSeconds = current.timer.totalSeconds,
                    isRunning = false,
                    isFinished = false,
                )
            )
        }
    }

    private fun vibrateAlert() {
        runCatching {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 220, 120, 260), -1))
        }
    }

    // --- Stopwatch ---
    fun toggleStopwatch() {
        val sw = _toolsState.value.stopwatch
        if (sw.isRunning) {
            stopwatchJob?.cancel()
            stopwatchAccumulatedMs = sw.elapsedMs
            _toolsState.update { it.copy(stopwatch = it.stopwatch.copy(isRunning = false)) }
        } else {
            stopwatchBaseMs = SystemClock.elapsedRealtime()
            _toolsState.update { it.copy(stopwatch = it.stopwatch.copy(isRunning = true)) }
            stopwatchJob?.cancel()
            stopwatchJob = scope.launch {
                while (isActive) {
                    val elapsed = stopwatchAccumulatedMs + (SystemClock.elapsedRealtime() - stopwatchBaseMs)
                    _toolsState.update {
                        it.copy(stopwatch = it.stopwatch.copy(elapsedMs = elapsed))
                    }
                    delay(50L)
                }
            }
        }
    }

    fun recordStopwatchLap() {
        val sw = _toolsState.value.stopwatch
        if (sw.elapsedMs <= 0L) return
        _toolsState.update {
            it.copy(stopwatch = it.stopwatch.copy(lapsMs = listOf(sw.elapsedMs) + it.stopwatch.lapsMs.take(19)))
        }
    }

    fun resetStopwatch() {
        stopwatchJob?.cancel()
        stopwatchAccumulatedMs = 0L
        stopwatchBaseMs = 0L
        _toolsState.update {
            it.copy(stopwatch = StopwatchState())
        }
    }

    // --- Calculator ---
    fun onCalcKey(key: String) {
        _toolsState.update { current ->
            val calc = current.calculator
            val next = processCalculatorInput(calc, key)
            current.copy(calculator = next)
        }
    }

    private fun processCalculatorInput(calc: CalculatorState, key: String): CalculatorState {
        return when (key) {
            "C" -> CalculatorState()
            "⌫" -> {
                val expr = calc.expression.dropLast(1)
                CalculatorState(
                    expression = expr,
                    display = expr.ifBlank { "0" },
                    error = null,
                )
            }
            "=" -> {
                if (calc.expression.isBlank()) return calc
                val result = evaluateExpression(calc.expression)
                if (result == null) {
                    calc.copy(error = "Ошибка выражения")
                } else {
                    val formatted = formatDouble(result)
                    CalculatorState(
                        expression = formatted,
                        display = formatted,
                        error = null,
                    )
                }
            }
            "%" -> {
                val result = evaluateExpression(calc.expression.ifBlank { calc.display }) ?: return calc
                val pct = formatDouble(result / 100.0)
                CalculatorState(expression = pct, display = pct, error = null)
            }
            "+/-" -> {
                val expr = calc.expression.ifBlank { calc.display }
                val toggled = if (expr.startsWith("-")) expr.drop(1) else if (expr != "0") "-$expr" else "0"
                CalculatorState(expression = if (toggled == "0") "" else toggled, display = toggled)
            }
            else -> {
                val ops = setOf("+", "-", "×", "÷")
                val raw = calc.expression
                val updated = when {
                    key in ops && raw.isEmpty() -> if (key == "-") "-" else ""
                    key in ops && raw.lastOrNull()?.toString() in ops -> raw.dropLast(1) + key
                    key == "." -> {
                        val lastToken = raw.split("+", "-", "×", "÷").lastOrNull().orEmpty()
                        if (lastToken.contains(".")) raw else if (lastToken.isEmpty()) "${raw}0." else "$raw."
                    }
                    else -> if (raw == "0" && key !in ops) key else raw + key
                }
                CalculatorState(
                    expression = updated,
                    display = updated.ifBlank { "0" },
                    error = null,
                )
            }
        }
    }

    private fun evaluateExpression(rawExpr: String): Double? {
        return runCatching {
            val expr = rawExpr.replace("×", "*").replace("÷", "/").replace("−", "-")
            val parser = object {
                var pos = -1
                var ch = 0

                fun nextChar() {
                    ch = if (++pos < expr.length) expr[pos].code else -1
                }

                fun eat(charToEat: Int): Boolean {
                    while (ch == ' '.code) nextChar()
                    if (ch == charToEat) {
                        nextChar()
                        return true
                    }
                    return false
                }

                fun parse(): Double {
                    nextChar()
                    val x = parseExpression()
                    if (pos < expr.length) throw IllegalArgumentException("Unexpected char")
                    return x
                }

                fun parseExpression(): Double {
                    var x = parseTerm()
                    while (true) {
                        when {
                            eat('+'.code) -> x += parseTerm()
                            eat('-'.code) -> x -= parseTerm()
                            else -> return x
                        }
                    }
                }

                fun parseTerm(): Double {
                    var x = parseFactor()
                    while (true) {
                        when {
                            eat('*'.code) -> x *= parseFactor()
                            eat('/'.code) -> {
                                val divisor = parseFactor()
                                if (divisor == 0.0) throw ArithmeticException("Division by zero")
                                x /= divisor
                            }
                            else -> return x
                        }
                    }
                }

                fun parseFactor(): Double {
                    if (eat('+'.code)) return parseFactor()
                    if (eat('-'.code)) return -parseFactor()
                    val startPos = pos
                    while ((ch in '0'.code..'9'.code) || ch == '.'.code) nextChar()
                    if (startPos == pos) throw IllegalArgumentException("Expected number")
                    return expr.substring(startPos, pos).toDouble()
                }
            }
            val value = parser.parse()
            if (value.isNaN() || value.isInfinite()) null else value
        }.getOrNull()
    }

    private fun formatDouble(value: Double): String {
        if (abs(value - value.toLong()) < 1e-9) {
            return value.toLong().toString()
        }
        return String.format(java.util.Locale.US, "%.6f", value).trimEnd('0').trimEnd('.')
    }
}
