package com.example.data.repository

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.TrafficStats
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import com.example.data.model.BatteryState
import com.example.data.model.NetworkState
import com.example.data.model.SystemState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.abs
import kotlin.math.max

class SystemTelemetryRepository(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val _batteryState = MutableStateFlow(BatteryState())
    val batteryState: StateFlow<BatteryState> = _batteryState.asStateFlow()

    private val _systemState = MutableStateFlow(SystemState())
    val systemState: StateFlow<SystemState> = _systemState.asStateFlow()

    private val _networkState = MutableStateFlow(NetworkState())
    val networkState: StateFlow<NetworkState> = _networkState.asStateFlow()

    private val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    private val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val connectivityManager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val wifiManager =
        context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

    private var lastRxBytes: Long = -1L
    private var lastTxBytes: Long = -1L
    private var lastSampleTimeMs: Long = 0L
    private val rxHistory = ArrayDeque<Float>(24)

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            if (intent != null) {
                parseBatteryIntent(intent)
            }
        }
    }

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            refreshNetworkMetadata()
        }

        override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
            refreshNetworkMetadata()
        }

        override fun onLost(network: Network) {
            refreshNetworkMetadata()
        }
    }

    init {
        registerReceivers()
        startPollingLoop()
    }

    private fun registerReceivers() {
        val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val sticky = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(batteryReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            context.registerReceiver(batteryReceiver, filter)
        }
        if (sticky != null) {
            parseBatteryIntent(sticky)
        }

        runCatching {
            connectivityManager.registerDefaultNetworkCallback(networkCallback)
        }
        refreshNetworkMetadata()
        refreshSystemMetrics()
    }

    private fun startPollingLoop() {
        scope.launch {
            while (isActive) {
                sampleTrafficAndSystem()
                delay(1000L)
            }
        }
    }

    private fun parseBatteryIntent(intent: Intent) {
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
        val pct = if (level >= 0) ((level * 100f) / scale).toInt().coerceIn(0, 100) else 0

        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, BatteryManager.BATTERY_STATUS_UNKNOWN)
        val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL && plugged != 0

        val statusRu = when (status) {
            BatteryManager.BATTERY_STATUS_CHARGING -> "Заряжается"
            BatteryManager.BATTERY_STATUS_FULL -> "Заряжен"
            BatteryManager.BATTERY_STATUS_DISCHARGING -> "Разряжается"
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Не заряжается"
            else -> "Мониторинг"
        }

        val chargeSourceRu = when (plugged) {
            BatteryManager.BATTERY_PLUGGED_AC -> "Адаптер сети"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB-порт"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Беспроводная"
            else -> if (isCharging) "Внешнее питание" else "От батареи"
        }

        val tempTenths = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0)
        val tempC = tempTenths / 10f

        val voltageMv = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
        val voltageV = voltageMv / 1000f

        val healthCode = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN)
        val healthRu = when (healthCode) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Хорошее"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Перегрев"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Изношена"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Высокое U"
            BatteryManager.BATTERY_HEALTH_COLD -> "Переохлаждение"
            else -> "Норма"
        }

        val tech = intent.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY)?.ifBlank { "Li-ion" } ?: "Li-ion"

        val currentUa = runCatching {
            batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        }.getOrDefault(0)
        val currentMa = if (currentUa == Int.MIN_VALUE) 0 else abs(currentUa / 1000)

        _batteryState.value = BatteryState(
            levelPercent = pct,
            isCharging = isCharging,
            chargeSourceRu = chargeSourceRu,
            statusRu = statusRu,
            temperatureC = tempC,
            voltageV = voltageV,
            currentMa = currentMa,
            healthRu = healthRu,
            technology = tech,
        )
    }

    fun refreshSystemMetrics() {
        val memInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memInfo)

        val totalMb = (memInfo.totalMem / (1024L * 1024L)).coerceAtLeast(1L)
        val availMb = memInfo.availMem / (1024L * 1024L)
        val usedPercent = (((totalMb - availMb).toFloat() / totalMb.toFloat()) * 100f)
            .toInt()
            .coerceIn(0, 100)

        val statFs = StatFs(Environment.getDataDirectory().path)
        val totalStorageGb = statFs.totalBytes / (1024f * 1024f * 1024f)
        val availStorageGb = statFs.availableBytes / (1024f * 1024f * 1024f)

        val tempC = _batteryState.value.temperatureC
        val thermalRu = when {
            tempC >= 43f -> "Горячий"
            tempC >= 37f -> "Тёплый"
            else -> "Норма"
        }

        val uptimeSec = SystemClock.elapsedRealtime() / 1000L
        val hours = uptimeSec / 3600L
        val mins = (uptimeSec % 3600L) / 60L
        val uptimeFormatted = if (hours > 0) "${hours}ч ${mins}м" else "${mins}м"

        val cacheKb = (directorySize(context.cacheDir) / 1024L).coerceAtLeast(0L)

        _systemState.value = SystemState(
            batteryTempC = tempC,
            thermalStatusRu = thermalRu,
            availableRamMb = availMb,
            totalRamMb = totalMb,
            ramUsagePercent = usedPercent,
            isLowMemory = memInfo.lowMemory,
            availableStorageGb = availStorageGb,
            totalStorageGb = totalStorageGb,
            cpuCores = Runtime.getRuntime().availableProcessors(),
            uptimeFormatted = uptimeFormatted,
            appCacheKb = cacheKb,
        )
    }

    fun clearAppCache(): Long {
        val before = directorySize(context.cacheDir)
        context.cacheDir.listFiles()?.forEach { file ->
            file.deleteRecursively()
        }
        refreshSystemMetrics()
        return (before / 1024L).coerceAtLeast(0L)
    }

    private fun directorySize(dir: File?): Long {
        if (dir == null || !dir.exists()) return 0L
        if (dir.isFile) return dir.length()
        return dir.listFiles()?.sumOf { directorySize(it) } ?: 0L
    }

    private fun sampleTrafficAndSystem() {
        refreshSystemMetrics()

        val now = SystemClock.elapsedRealtime()
        val rx = TrafficStats.getTotalRxBytes()
        val tx = TrafficStats.getTotalTxBytes()

        var rxBps = 0L
        var txBps = 0L

        if (rx >= 0 && tx >= 0 && lastRxBytes >= 0 && lastTxBytes >= 0 && lastSampleTimeMs > 0L) {
            val dtMs = max(200L, now - lastSampleTimeMs)
            val dRx = (rx - lastRxBytes).coerceAtLeast(0L)
            val dTx = (tx - lastTxBytes).coerceAtLeast(0L)
            rxBps = (dRx * 1000L) / dtMs
            txBps = (dTx * 1000L) / dtMs
        }

        if (rx >= 0) lastRxBytes = rx
        if (tx >= 0) lastTxBytes = tx
        lastSampleTimeMs = now

        val rxKbps = rxBps / 1024f
        rxHistory.addLast(rxKbps)
        while (rxHistory.size > 24) {
            rxHistory.removeFirst()
        }

        refreshNetworkMetadata(rxBps = rxBps, txBps = txBps)
    }

    private fun refreshNetworkMetadata(
        rxBps: Long = _networkState.value.rxBytesPerSec,
        txBps: Long = _networkState.value.txBytesPerSec,
    ) {
        val activeNetwork = connectivityManager.activeNetwork
        val caps = if (activeNetwork != null) {
            connectivityManager.getNetworkCapabilities(activeNetwork)
        } else {
            null
        }

        val hasInternet = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        val isWifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        val isCellular = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
        val isEthernet = caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true

        val transportRu = when {
            !hasInternet && caps == null -> "Нет подключения"
            isWifi -> "Wi-Fi"
            isCellular -> "Мобильная сеть"
            isEthernet -> "Ethernet"
            else -> "Подключено"
        }

        var networkName = if (hasInternet) transportRu else "Автономный режим"
        var signalBars = if (hasInternet) 3 else 0
        var linkSpeedMbps = 0

        if (isWifi) {
            @Suppress("DEPRECATION")
            val wifiInfo = wifiManager.connectionInfo
            if (wifiInfo != null) {
                linkSpeedMbps = wifiInfo.linkSpeed.coerceAtLeast(0)
                val rssi = wifiInfo.rssi
                signalBars = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    wifiManager.calculateSignalLevel(rssi).coerceIn(0, 4)
                } else {
                    @Suppress("DEPRECATION")
                    WifiManager.calculateSignalLevel(rssi, 5)
                }
                val rawSsid = wifiInfo.ssid.orEmpty().trim('"')
                if (rawSsid.isNotBlank() && rawSsid != "<unknown ssid>") {
                    networkName = rawSsid
                } else {
                    networkName = "Wi-Fi (${linkSpeedMbps} Мбит/с)"
                }
            }
        } else if (isCellular) {
            val downBandwidthKbps = caps?.linkDownstreamBandwidthKbps ?: 0
            linkSpeedMbps = downBandwidthKbps / 1000
            signalBars = 4
            networkName = if (linkSpeedMbps > 20) "5G / LTE+" else "LTE / 4G"
        }

        _networkState.value = NetworkState(
            isConnected = caps != null && hasInternet,
            transportTypeRu = transportRu,
            isWifi = isWifi,
            isCellular = isCellular,
            networkName = networkName,
            signalBars = signalBars,
            linkSpeedMbps = linkSpeedMbps,
            rxBytesPerSec = rxBps,
            txBytesPerSec = txBps,
            speedHistoryRxKbps = rxHistory.toList(),
        )
    }
}
