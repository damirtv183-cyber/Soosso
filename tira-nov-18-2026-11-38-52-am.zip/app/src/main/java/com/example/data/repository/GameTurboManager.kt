package com.example.data.repository

import android.app.NotificationManager
import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class GameTurboManager(
    private val context: Context,
    private val settingsRepository: SettingsRepository,
) {
    private val notificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    suspend fun setGameTurboEnabled(
        enabled: Boolean,
        enableDnd: Boolean,
    ): Result<String> {
        settingsRepository.updateSettings { it.copy(gameTurboActive = enabled) }

        if (enabled && enableDnd) {
            if (notificationManager.isNotificationPolicyAccessGranted) {
                runCatching {
                    notificationManager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
                }
                val msg = "Game Turbo активен: приоритетный режим включён"
                _statusMessage.value = msg
                return Result.success(msg)
            } else {
                val msg = "Game Turbo активен (выдайте доступ к «Не беспокоить» для блокировки уведомлений)"
                _statusMessage.value = msg
                return Result.success(msg)
            }
        } else if (!enabled && notificationManager.isNotificationPolicyAccessGranted) {
            runCatching {
                notificationManager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
            }
            val msg = "Game Turbo отключён"
            _statusMessage.value = msg
            return Result.success(msg)
        }

        val msg = if (enabled) "Game Turbo активен" else "Game Turbo отключён"
        _statusMessage.value = msg
        return Result.success(msg)
    }

    fun clearMessage() {
        _statusMessage.value = null
    }
}
