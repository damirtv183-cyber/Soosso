package com.example.data.repository

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.SystemClock
import com.example.data.model.MusicState
import com.example.data.model.NotificationBanner
import com.example.service.TiraNotificationListenerService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class MediaRepository(
    private val context: Context,
    private val installedAppsRepository: InstalledAppsRepository,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val _musicState = MutableStateFlow(MusicState())
    val musicState: StateFlow<MusicState> = _musicState.asStateFlow()

    private val _latestNotification = MutableStateFlow<NotificationBanner?>(null)
    val latestNotification: StateFlow<NotificationBanner?> = _latestNotification.asStateFlow()

    private val mediaSessionManager =
        context.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager

    private val listenerComponent by lazy {
        ComponentName(context, TiraNotificationListenerService::class.java)
    }

    private var activeController: MediaController? = null
    private var isSessionsListenerRegistered = false

    private val controllerCallback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) {
            publishCurrentControllerState()
        }

        override fun onMetadataChanged(metadata: MediaMetadata?) {
            publishCurrentControllerState()
        }

        override fun onSessionDestroyed() {
            refreshActiveSessions()
        }
    }

    private val sessionsChangedListener =
        MediaSessionManager.OnActiveSessionsChangedListener { controllers ->
            updateControllers(controllers.orEmpty())
        }

    init {
        refreshActiveSessions()
        startProgressTicker()
    }

    fun refreshActiveSessions() {
        val listenerGranted = PermissionHelper.getStatus(context).isNotificationListenerEnabled
        if (!listenerGranted) {
            unregisterControllerCallback()
            _musicState.value = MusicState(listenerConnected = false)
            return
        }

        runCatching {
            if (!isSessionsListenerRegistered) {
                mediaSessionManager.addOnActiveSessionsChangedListener(
                    sessionsChangedListener,
                    listenerComponent,
                )
                isSessionsListenerRegistered = true
            }
            val controllers = mediaSessionManager.getActiveSessions(listenerComponent)
            updateControllers(controllers)
        }.onFailure {
            _musicState.value = MusicState(listenerConnected = false)
        }
    }

    private fun updateControllers(controllers: List<MediaController>) {
        val preferred = controllers.firstOrNull {
            it.playbackState?.state == PlaybackState.STATE_PLAYING
        } ?: controllers.firstOrNull()

        if (preferred?.sessionToken != activeController?.sessionToken) {
            unregisterControllerCallback()
            activeController = preferred
            preferred?.registerCallback(controllerCallback)
        }
        publishCurrentControllerState()
    }

    private fun unregisterControllerCallback() {
        runCatching { activeController?.unregisterCallback(controllerCallback) }
        activeController = null
    }

    private fun publishCurrentControllerState() {
        val controller = activeController
        val listenerConnected = PermissionHelper.getStatus(context).isNotificationListenerEnabled

        if (controller == null) {
            _musicState.value = MusicState(
                hasActiveSession = false,
                listenerConnected = listenerConnected,
            )
            return
        }

        val metadata = controller.metadata
        val playback = controller.playbackState

        val title = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: metadata?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
            ?: "Без названия"
        val artist = metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: metadata?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: "Неизвестный исполнитель"
        val album = metadata?.getString(MediaMetadata.METADATA_KEY_ALBUM).orEmpty()
        val durationMs = metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION)?.coerceAtLeast(0L) ?: 0L
        val art: Bitmap? = metadata?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: metadata?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: metadata?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)

        val isPlaying = playback?.state == PlaybackState.STATE_PLAYING ||
            playback?.state == PlaybackState.STATE_BUFFERING

        val positionMs = computeEstimatedPosition(playback, durationMs)
        val pkg = controller.packageName.orEmpty()
        val appLabel = if (pkg.isNotBlank()) installedAppsRepository.getAppLabel(pkg) else ""

        _musicState.value = MusicState(
            hasActiveSession = true,
            title = title,
            artist = artist,
            album = album,
            sourceAppName = appLabel,
            packageName = pkg,
            albumArt = art,
            isPlaying = isPlaying,
            positionMs = positionMs,
            durationMs = durationMs,
            listenerConnected = listenerConnected,
        )
    }

    private fun computeEstimatedPosition(playback: PlaybackState?, durationMs: Long): Long {
        if (playback == null) return 0L
        var pos = playback.position.coerceAtLeast(0L)
        if (playback.state == PlaybackState.STATE_PLAYING && playback.lastPositionUpdateTime > 0L) {
            val delta = (SystemClock.elapsedRealtime() - playback.lastPositionUpdateTime).coerceAtLeast(0L)
            pos += (delta * playback.playbackSpeed).toLong()
        }
        return if (durationMs > 0L) pos.coerceIn(0L, durationMs) else pos
    }

    private fun startProgressTicker() {
        scope.launch {
            while (isActive) {
                if (_musicState.value.isPlaying && activeController != null) {
                    publishCurrentControllerState()
                }
                delay(1000L)
            }
        }
    }

    fun togglePlayPause(): Boolean {
        val controller = activeController ?: return false
        val state = controller.playbackState?.state
        if (state == PlaybackState.STATE_PLAYING) {
            controller.transportControls.pause()
        } else {
            controller.transportControls.play()
        }
        return true
    }

    fun skipNext(): Boolean {
        val controller = activeController ?: return false
        controller.transportControls.skipToNext()
        return true
    }

    fun skipPrevious(): Boolean {
        val controller = activeController ?: return false
        controller.transportControls.skipToPrevious()
        return true
    }

    fun seekTo(positionMs: Long): Boolean {
        val controller = activeController ?: return false
        controller.transportControls.seekTo(positionMs.coerceAtLeast(0L))
        return true
    }

    fun onNotificationPosted(packageName: String, title: String, text: String) {
        if (packageName == context.packageName) return
        if (title.isBlank() && text.isBlank()) return
        val appName = installedAppsRepository.getAppLabel(packageName)
        _latestNotification.value = NotificationBanner(
            appName = appName,
            title = title.ifBlank { appName },
            text = text,
            timestampMs = System.currentTimeMillis(),
        )
    }

    fun dismissNotificationBanner() {
        _latestNotification.value = null
    }
}
