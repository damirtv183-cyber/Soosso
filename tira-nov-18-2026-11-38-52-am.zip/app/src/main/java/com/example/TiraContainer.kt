package com.example

import android.content.Context
import com.example.data.repository.GameTurboManager
import com.example.data.repository.InstalledAppsRepository
import com.example.data.repository.MediaRepository
import com.example.data.repository.SettingsRepository
import com.example.data.repository.SystemTelemetryRepository
import com.example.data.repository.ToolsManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class TiraContainer(context: Context) {
    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val settingsRepository = SettingsRepository(appContext)
    val installedAppsRepository = InstalledAppsRepository(appContext)
    val systemTelemetryRepository = SystemTelemetryRepository(appContext)
    val mediaRepository = MediaRepository(appContext, installedAppsRepository)
    val toolsManager = ToolsManager(appContext)
    val gameTurboManager = GameTurboManager(appContext, settingsRepository)

    init {
        scope.launch {
            val apps = installedAppsRepository.refreshInstalledApps()
            if (apps.isNotEmpty()) {
                val preferredKeywords = listOf(
                    "settings", "chrome", "browser", "camera", "clock",
                    "deskclock", "calculator", "calendar", "gallery", "photos", "music"
                )
                val prioritized = apps.sortedBy { app ->
                    val idx = preferredKeywords.indexOfFirst { kw ->
                        app.packageName.lowercase().contains(kw)
                    }
                    if (idx >= 0) idx else 100
                }.take(SettingsRepository.MAX_PINNED_APPS).map { it.packageName }

                settingsRepository.seedDefaultPinnedPackagesIfEmpty(prioritized)
            }
        }
    }
}
