package com.example

import android.app.Application

class TiraApplication : Application() {
    lateinit var container: TiraContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = TiraContainer(this)
    }
}
