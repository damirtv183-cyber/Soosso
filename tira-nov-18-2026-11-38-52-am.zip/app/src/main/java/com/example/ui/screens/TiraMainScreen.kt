package com.example.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.PowerSettingsNew
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.IslandSection
import com.example.ui.island.DynamicIslandHost
import com.example.ui.theme.AmberThermal
import com.example.ui.theme.CoralAlert
import com.example.ui.theme.ElevatedSlate
import com.example.ui.theme.EmeraldMint
import com.example.ui.theme.HairlineBorder
import com.example.ui.theme.ManropeFamily
import com.example.ui.theme.MidnightCard
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.SmokedSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun TiraMainScreen(viewModel: TiraViewModel) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val selectedSection by viewModel.selectedSection.collectAsStateWithLifecycle()
    val previewExpanded by viewModel.previewExpanded.collectAsStateWithLifecycle()
    val permissions by viewModel.permissions.collectAsStateWithLifecycle()
    val installedApps by viewModel.installedApps.collectAsStateWithLifecycle()
    val pinnedApps by viewModel.pinnedApps.collectAsStateWithLifecycle()
    val detectedGames by viewModel.detectedGames.collectAsStateWithLifecycle()
    val music by viewModel.music.collectAsStateWithLifecycle()
    val battery by viewModel.battery.collectAsStateWithLifecycle()
    val system by viewModel.system.collectAsStateWithLifecycle()
    val network by viewModel.network.collectAsStateWithLifecycle()
    val tools by viewModel.tools.collectAsStateWithLifecycle()
    val banner by viewModel.notificationBanner.collectAsStateWithLifecycle()
    val isOverlayRunning by viewModel.isOverlayServiceRunning.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    val accent = MaterialTheme.colorScheme.primary

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
    ) {
        viewModel.refreshPermissionsAndSessions()
    }

    LaunchedEffect(Unit) {
        viewModel.snackbarMessage.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    val requestPostNotificationsAction = {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val startOrStopOverlayAction: () -> Unit = {
        if (!isOverlayRunning &&
            permissions.canDrawOverlays &&
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            !permissions.isPostNotificationsGranted
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        viewModel.toggleOverlayService(!isOverlayRunning)
    }

    val previewCallbacks = remember(viewModel) { viewModel.buildPreviewCallbacks() }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianVoid),
    ) {
        val isWideScreen = maxWidth >= 680.dp

        if (isWideScreen) {
            Scaffold(
                containerColor = ObsidianVoid,
                snackbarHost = { SnackbarHost(snackbarHostState) },
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                ) {
                    // Tablet / Wide NavigationRail with all 8 sections
                    NavigationRail(
                        containerColor = SmokedSurface,
                        modifier = Modifier
                            .fillMaxHeight()
                            .statusBarsPadding()
                            .windowInsetsPadding(WindowInsets.navigationBars)
                            .verticalScroll(rememberScrollState()),
                    ) {
                        Spacer(Modifier.height(8.dp))
                        IslandSection.entries.forEach { section ->
                            val selected = section == selectedSection
                            NavigationRailItem(
                                selected = selected,
                                onClick = { viewModel.selectSection(section) },
                                icon = { Icon(section.icon, contentDescription = section.titleRu) },
                                label = {
                                    Text(
                                        text = section.shortTitleRu,
                                        fontFamily = ManropeFamily,
                                        fontSize = 11.sp,
                                        maxLines = 1,
                                    )
                                },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = Color.Black,
                                    selectedTextColor = accent,
                                    indicatorColor = accent,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary,
                                ),
                                modifier = Modifier.testTag("section_tab_${section.name.lowercase()}"),
                            )
                        }
                    }

                    // Left primary detail pane + Right Live Island Stage
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .statusBarsPadding()
                            .windowInsetsPadding(WindowInsets.navigationBars)
                            .padding(horizontal = 20.dp, vertical = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(20.dp),
                    ) {
                        Column(
                            modifier = Modifier
                                .weight(1.15f)
                                .fillMaxHeight()
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                        ) {
                            TiraTopBarHeader(
                                isOverlayRunning = isOverlayRunning,
                                canDrawOverlays = permissions.canDrawOverlays,
                                accent = accent,
                                onToggleOverlay = startOrStopOverlayAction,
                            )

                            ActiveSectionContent(
                                selectedSection = selectedSection,
                                settings = settings,
                                permissions = permissions,
                                installedApps = installedApps,
                                pinnedApps = pinnedApps,
                                detectedGames = detectedGames,
                                music = music,
                                battery = battery,
                                system = system,
                                network = network,
                                tools = tools,
                                viewModel = viewModel,
                                onRequestPostNotifications = requestPostNotificationsAction,
                            )
                        }

                        // Supporting Pane: Live Interactive Island Stage
                        Column(
                            modifier = Modifier
                                .weight(0.95f)
                                .fillMaxHeight()
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(14.dp),
                        ) {
                            LiveIslandPreviewStage(
                                previewExpanded = previewExpanded,
                                selectedSection = selectedSection,
                                settings = settings,
                                pinnedApps = pinnedApps,
                                detectedGames = detectedGames,
                                music = music,
                                battery = battery,
                                system = system,
                                network = network,
                                tools = tools,
                                banner = banner,
                                callbacks = previewCallbacks,
                                onTogglePreview = { viewModel.togglePreviewExpanded() },
                            )

                            if (!permissions.canDrawOverlays || !permissions.isNotificationListenerEnabled) {
                                QuickPermissionsCard(
                                    canDrawOverlays = permissions.canDrawOverlays,
                                    listenerEnabled = permissions.isNotificationListenerEnabled,
                                    onGrantOverlay = { viewModel.openOverlayPermissionSettings() },
                                    onGrantListener = { viewModel.openNotificationListenerSettings() },
                                )
                            }
                        }
                    }
                }
            }
        } else {
            // Compact Phone Layout
            val primaryNavSections = listOf(
                IslandSection.LAUNCHER,
                IslandSection.MUSIC,
                IslandSection.TOOLS,
                IslandSection.SETTINGS,
            )

            Scaffold(
                containerColor = ObsidianVoid,
                snackbarHost = { SnackbarHost(snackbarHostState) },
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                bottomBar = {
                    NavigationBar(
                        containerColor = SmokedSurface,
                        windowInsets = WindowInsets.navigationBars,
                    ) {
                        primaryNavSections.forEach { section ->
                            val selected = selectedSection == section
                            NavigationBarItem(
                                selected = selected,
                                onClick = { viewModel.selectSection(section) },
                                icon = { Icon(section.icon, contentDescription = section.titleRu) },
                                label = {
                                    Text(
                                        text = section.shortTitleRu,
                                        fontFamily = ManropeFamily,
                                        fontSize = 11.sp,
                                        maxLines = 1,
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.Black,
                                    selectedTextColor = accent,
                                    indicatorColor = accent,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary,
                                ),
                            )
                        }
                    }
                },
            ) { innerPadding ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .statusBarsPadding()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    TiraTopBarHeader(
                        isOverlayRunning = isOverlayRunning,
                        canDrawOverlays = permissions.canDrawOverlays,
                        accent = accent,
                        onToggleOverlay = startOrStopOverlayAction,
                    )

                    if (!permissions.canDrawOverlays || !permissions.isNotificationListenerEnabled) {
                        QuickPermissionsCard(
                            canDrawOverlays = permissions.canDrawOverlays,
                            listenerEnabled = permissions.isNotificationListenerEnabled,
                            onGrantOverlay = { viewModel.openOverlayPermissionSettings() },
                            onGrantListener = { viewModel.openNotificationListenerSettings() },
                        )
                    }

                    LiveIslandPreviewStage(
                        previewExpanded = previewExpanded,
                        selectedSection = selectedSection,
                        settings = settings,
                        pinnedApps = pinnedApps,
                        detectedGames = detectedGames,
                        music = music,
                        battery = battery,
                        system = system,
                        network = network,
                        tools = tools,
                        banner = banner,
                        callbacks = previewCallbacks,
                        onTogglePreview = { viewModel.togglePreviewExpanded() },
                    )

                    // All 8 sections pill switcher
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        IslandSection.entries.forEach { section ->
                            val selected = section == selectedSection
                            val chipBg by animateColorAsState(
                                targetValue = if (selected) accent else MidnightCard,
                                animationSpec = tween(200),
                                label = "chip_bg_${section.name}",
                            )
                            val chipFg by animateColorAsState(
                                targetValue = if (selected) Color.Black else TextPrimary,
                                animationSpec = tween(200),
                                label = "chip_fg_${section.name}",
                            )
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(chipBg)
                                    .border(1.dp, if (selected) accent else HairlineBorder, RoundedCornerShape(14.dp))
                                    .clickable { viewModel.selectSection(section) }
                                    .padding(horizontal = 12.dp, vertical = 10.dp)
                                    .testTag("section_tab_${section.name.lowercase()}"),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                Icon(
                                    imageVector = section.icon,
                                    contentDescription = section.titleRu,
                                    tint = if (selected) Color.Black else TextSecondary,
                                    modifier = Modifier.size(16.dp),
                                )
                                Text(
                                    text = section.titleRu,
                                    color = chipFg,
                                    fontFamily = ManropeFamily,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 12.sp,
                                )
                            }
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .widthIn(max = 640.dp)
                            .align(Alignment.CenterHorizontally),
                    ) {
                        ActiveSectionContent(
                            selectedSection = selectedSection,
                            settings = settings,
                            permissions = permissions,
                            installedApps = installedApps,
                            pinnedApps = pinnedApps,
                            detectedGames = detectedGames,
                            music = music,
                            battery = battery,
                            system = system,
                            network = network,
                            tools = tools,
                            viewModel = viewModel,
                            onRequestPostNotifications = requestPostNotificationsAction,
                        )
                    }

                    Spacer(Modifier.height(12.dp))
                }
            }
        }
    }
}

@Composable
private fun TiraTopBarHeader(
    isOverlayRunning: Boolean,
    canDrawOverlays: Boolean,
    accent: Color,
    onToggleOverlay: () -> Unit,
) {
    Surface(
        color = MidnightCard,
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, HairlineBorder, RoundedCornerShape(24.dp)),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Column(modifier = Modifier.weight(1f).padding(end = 10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(if (isOverlayRunning) EmeraldMint else accent),
                    )
                    Text(
                        text = "Tira",
                        color = TextPrimary,
                        fontFamily = ManropeFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp,
                    )
                }
                Text(
                    text = if (isOverlayRunning) "Остров активен поверх окон" else "Dynamic Island Pro",
                    color = if (isOverlayRunning) EmeraldMint else TextSecondary,
                    fontFamily = ManropeFamily,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }

            Button(
                onClick = onToggleOverlay,
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isOverlayRunning) CoralAlert.copy(alpha = 0.2f) else accent,
                    contentColor = if (isOverlayRunning) CoralAlert else Color.Black,
                ),
                modifier = Modifier.testTag("overlay_toggle_button"),
            ) {
                Icon(
                    imageVector = if (isOverlayRunning) Icons.Rounded.PowerSettingsNew else Icons.Rounded.Layers,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp),
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = when {
                        isOverlayRunning -> "Остановить"
                        !canDrawOverlays -> "Разрешить и запуск"
                        else -> "Запустить остров"
                    },
                    fontFamily = ManropeFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                )
            }
        }
    }
}

@Composable
private fun QuickPermissionsCard(
    canDrawOverlays: Boolean,
    listenerEnabled: Boolean,
    onGrantOverlay: () -> Unit,
    onGrantListener: () -> Unit,
) {
    Surface(
        color = Color.White.copy(alpha = 0.05f),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color.White.copy(alpha = 0.18f), RoundedCornerShape(20.dp)),
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Rounded.WarningAmber, contentDescription = null, tint = TextPrimary, modifier = Modifier.size(18.dp))
                Text(
                    text = "Разрешения для полного функционала",
                    color = TextPrimary,
                    fontFamily = ManropeFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                )
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!canDrawOverlays) {
                    Button(
                        onClick = onGrantOverlay,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = TextPrimary, contentColor = Color.Black),
                    ) {
                        Text("Поверх окон", fontFamily = ManropeFamily, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
                if (!listenerEnabled) {
                    Button(
                        onClick = onGrantListener,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = ElevatedSlate, contentColor = TextPrimary),
                    ) {
                        Text("Медиа / Уведомл.", fontFamily = ManropeFamily, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun LiveIslandPreviewStage(
    previewExpanded: Boolean,
    selectedSection: IslandSection,
    settings: com.example.data.model.IslandSettings,
    pinnedApps: List<com.example.data.model.InstalledAppInfo>,
    detectedGames: List<com.example.data.model.InstalledAppInfo>,
    music: com.example.data.model.MusicState,
    battery: com.example.data.model.BatteryState,
    system: com.example.data.model.SystemState,
    network: com.example.data.model.NetworkState,
    tools: com.example.data.model.ToolsState,
    banner: com.example.data.model.NotificationBanner?,
    callbacks: com.example.ui.island.IslandCallbacks,
    onTogglePreview: () -> Unit,
) {
    val accent = settings.accent.primaryColor

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(26.dp))
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color.White.copy(alpha = 0.08f),
                        MidnightCard,
                    )
                )
            )
            .border(1.dp, HairlineBorder, RoundedCornerShape(26.dp))
            .padding(14.dp)
            .testTag("island_preview_stage"),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = "Предпросмотр острова",
                    color = TextSecondary,
                    fontFamily = ManropeFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 12.sp,
                )
                Text(
                    text = if (previewExpanded) "Свернуть" else "Нажмите на капсулу",
                    color = accent,
                    fontFamily = ManropeFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 11.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(onClick = onTogglePreview)
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                )
            }

            DynamicIslandHost(
                isExpanded = previewExpanded,
                activeSection = selectedSection,
                settings = settings,
                pinnedApps = pinnedApps,
                detectedGames = detectedGames,
                music = music,
                battery = battery,
                system = system,
                network = network,
                tools = tools,
                banner = banner,
                callbacks = callbacks,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

@Composable
private fun ActiveSectionContent(
    selectedSection: IslandSection,
    settings: com.example.data.model.IslandSettings,
    permissions: com.example.data.model.PermissionStatus,
    installedApps: List<com.example.data.model.InstalledAppInfo>,
    pinnedApps: List<com.example.data.model.InstalledAppInfo>,
    detectedGames: List<com.example.data.model.InstalledAppInfo>,
    music: com.example.data.model.MusicState,
    battery: com.example.data.model.BatteryState,
    system: com.example.data.model.SystemState,
    network: com.example.data.model.NetworkState,
    tools: com.example.data.model.ToolsState,
    viewModel: TiraViewModel,
    onRequestPostNotifications: () -> Unit,
) {
    AnimatedContent(
        targetState = selectedSection,
        transitionSpec = {
            fadeIn(tween(180)) togetherWith fadeOut(tween(120))
        },
        label = "main_section_transition",
    ) { section ->
        when (section) {
            IslandSection.LAUNCHER -> LauncherSectionScreen(
            pinnedApps = pinnedApps,
            allApps = installedApps,
            onMoveApp = viewModel::movePinnedApp,
            onRemoveApp = viewModel::removePinnedApp,
            onTogglePinApp = viewModel::togglePinApp,
            onLaunchApp = viewModel::launchApp,
            onRefreshApps = viewModel::refreshInstalledApps,
        )

        IslandSection.MUSIC -> MusicSectionScreen(
            music = music,
            onPlayPause = viewModel::musicPlayPause,
            onNext = viewModel::musicNext,
            onPrev = viewModel::musicPrev,
            onSeek = viewModel::musicSeek,
            onRequestListener = viewModel::openNotificationListenerSettings,
            onRefreshSessions = viewModel::refreshPermissionsAndSessions,
        )

        IslandSection.BATTERY -> BatterySectionScreen(battery = battery)

        IslandSection.SYSTEM -> SystemSectionScreen(
            system = system,
            onRefresh = viewModel::refreshSystemMetrics,
            onClearCache = viewModel::clearAppCache,
        )

        IslandSection.GAMING -> GamingSectionScreen(
            settings = settings,
            system = system,
            permissions = permissions,
            games = detectedGames,
            onToggleGameTurbo = viewModel::toggleGameTurbo,
            onToggleDnd = { v -> viewModel.updateSettings { it.copy(gameTurboDnd = v) } },
            onToggleKeepScreen = { v -> viewModel.updateSettings { it.copy(gameTurboKeepScreenOn = v) } },
            onToggleCompactHud = { v -> viewModel.updateSettings { it.copy(gameTurboCompactHud = v) } },
            onLaunchSystemGameTurbo = viewModel::launchSystemGameTurbo,
            onLaunchGame = viewModel::launchApp,
            onOpenDndSettings = viewModel::openDndPolicySettings,
        )

        IslandSection.NETWORK -> NetworkSectionScreen(
            network = network,
            onOpenInternetPanel = viewModel::openInternetPanel,
        )

        IslandSection.TOOLS -> ToolsSectionScreen(
            tools = tools,
            onTimerPreset = viewModel::setTimerPreset,
            onTimerAddSeconds = viewModel::addTimerSeconds,
            onTimerToggle = viewModel::toggleTimer,
            onTimerReset = viewModel::resetTimer,
            onStopwatchToggle = viewModel::toggleStopwatch,
            onStopwatchLap = viewModel::recordStopwatchLap,
            onStopwatchReset = viewModel::resetStopwatch,
            onCalcKey = viewModel::onCalcKey,
            onToggleFlashlight = viewModel::toggleFlashlight,
        )

        IslandSection.SETTINGS -> SettingsSectionScreen(
            settings = settings,
            permissions = permissions,
            onUpdateSettings = viewModel::updateSettings,
            onResetDefaults = viewModel::resetSettingsDefaults,
            onOpenOverlaySettings = viewModel::openOverlayPermissionSettings,
            onOpenListenerSettings = viewModel::openNotificationListenerSettings,
            onRequestPostNotifications = onRequestPostNotifications,
            onOpenDndSettings = viewModel::openDndPolicySettings,
        )
        }
    }
}
