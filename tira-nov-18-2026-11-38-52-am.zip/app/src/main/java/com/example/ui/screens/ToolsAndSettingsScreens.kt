package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.FlashlightOff
import androidx.compose.material.icons.rounded.FlashlightOn
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.WatchLater
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.IslandAccent
import com.example.data.model.IslandAnimStyle
import com.example.data.model.IslandSettings
import com.example.data.model.PermissionStatus
import com.example.data.model.ToolsState
import com.example.ui.theme.AmberThermal
import com.example.ui.theme.CoralAlert
import com.example.ui.theme.ElevatedSlate
import com.example.ui.theme.EmeraldMint
import com.example.ui.theme.HairlineBorder
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.ManropeFamily
import com.example.ui.theme.MidnightCard
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.util.formatStopwatchMs
import com.example.ui.util.formatTimerSeconds
import kotlin.math.roundToInt

@Composable
fun ToolsSectionScreen(
    tools: ToolsState,
    onTimerPreset: (Int) -> Unit,
    onTimerAddSeconds: (Int) -> Unit,
    onTimerToggle: () -> Unit,
    onTimerReset: () -> Unit,
    onStopwatchToggle: () -> Unit,
    onStopwatchLap: () -> Unit,
    onStopwatchReset: () -> Unit,
    onCalcKey: (String) -> Unit,
    onToggleFlashlight: () -> Unit,
) {
    val accent = MaterialTheme.colorScheme.primary
    var activeTool by rememberSaveable { mutableIntStateOf(0) }

    val tabs = listOf(
        Triple(0, "Таймер", Icons.Rounded.Timer),
        Triple(1, "Секундомер", Icons.Rounded.WatchLater),
        Triple(2, "Калькулятор", Icons.Rounded.Calculate),
        Triple(3, "Фонарик", Icons.Rounded.FlashlightOn),
    )

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            tabs.forEach { (idx, title, icon) ->
                val selected = activeTool == idx
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (selected) accent else MidnightCard)
                        .border(1.dp, if (selected) accent else HairlineBorder, RoundedCornerShape(16.dp))
                        .clickable { activeTool = idx }
                        .padding(vertical = 10.dp, horizontal = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = if (selected) Color.Black else TextSecondary,
                        modifier = Modifier.size(20.dp),
                    )
                    Text(
                        text = title,
                        color = if (selected) Color.Black else TextSecondary,
                        fontFamily = ManropeFamily,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }

        AnimatedContent(
            targetState = activeTool,
            transitionSpec = {
                fadeIn(tween(180)) togetherWith fadeOut(tween(120))
            },
            label = "tools_subtab",
        ) { toolIndex ->
            when (toolIndex) {
            0 -> {
                Surface(
                    color = MidnightCard,
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, HairlineBorder, RoundedCornerShape(24.dp)),
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                    ) {
                        Text(
                            text = formatTimerSeconds(tools.timer.remainingSeconds),
                            color = if (tools.timer.isFinished) AmberThermal else TextPrimary,
                            fontFamily = JetBrainsMonoFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 44.sp,
                        )
                        if (tools.timer.isFinished) {
                            Text(
                                text = "Таймер завершён!",
                                color = AmberThermal,
                                fontFamily = ManropeFamily,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            listOf(60 to "1 мин", 180 to "3 мин", 300 to "5 мин", 600 to "10 мин").forEach { (sec, label) ->
                                FilledTonalButton(
                                    onClick = { onTimerPreset(sec) },
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 10.dp),
                                    colors = ButtonDefaults.filledTonalButtonColors(
                                        containerColor = ElevatedSlate,
                                        contentColor = TextPrimary,
                                    ),
                                ) {
                                    Text(label, fontFamily = ManropeFamily, fontSize = 12.sp)
                                }
                            }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            FilledTonalButton(
                                onClick = { onTimerAddSeconds(-30) },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.filledTonalButtonColors(containerColor = ElevatedSlate, contentColor = TextPrimary),
                            ) {
                                Text("-30с", fontFamily = JetBrainsMonoFamily)
                            }
                            FilledTonalButton(
                                onClick = { onTimerAddSeconds(60) },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.filledTonalButtonColors(containerColor = ElevatedSlate, contentColor = TextPrimary),
                            ) {
                                Text("+1м", fontFamily = JetBrainsMonoFamily)
                            }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Button(
                                onClick = onTimerToggle,
                                modifier = Modifier.weight(1f).height(50.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color.Black),
                            ) {
                                Text(
                                    if (tools.timer.isRunning) "Пауза" else "Старт",
                                    fontFamily = ManropeFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                )
                            }
                            FilledTonalButton(
                                onClick = onTimerReset,
                                modifier = Modifier.height(50.dp),
                                colors = ButtonDefaults.filledTonalButtonColors(containerColor = ElevatedSlate, contentColor = TextPrimary),
                            ) {
                                Icon(Icons.Rounded.Refresh, contentDescription = "Сбросить")
                            }
                        }
                    }
                }
            }

            1 -> {
                Surface(
                    color = MidnightCard,
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, HairlineBorder, RoundedCornerShape(24.dp)),
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                    ) {
                        Text(
                            text = formatStopwatchMs(tools.stopwatch.elapsedMs),
                            color = TextPrimary,
                            fontFamily = JetBrainsMonoFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 40.sp,
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Button(
                                onClick = onStopwatchToggle,
                                modifier = Modifier.weight(1f).height(50.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color.Black),
                            ) {
                                Text(
                                    if (tools.stopwatch.isRunning) "Пауза" else "Старт",
                                    fontFamily = ManropeFamily,
                                    fontWeight = FontWeight.Bold,
                                )
                            }
                            FilledTonalButton(
                                onClick = onStopwatchLap,
                                modifier = Modifier.height(50.dp),
                                colors = ButtonDefaults.filledTonalButtonColors(containerColor = ElevatedSlate, contentColor = TextPrimary),
                            ) {
                                Icon(Icons.Rounded.Flag, contentDescription = "Круг")
                            }
                            FilledTonalButton(
                                onClick = onStopwatchReset,
                                modifier = Modifier.height(50.dp),
                                colors = ButtonDefaults.filledTonalButtonColors(containerColor = ElevatedSlate, contentColor = TextPrimary),
                            ) {
                                Icon(Icons.Rounded.Refresh, contentDescription = "Сброс")
                            }
                        }
                        if (tools.stopwatch.lapsMs.isNotEmpty()) {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                tools.stopwatch.lapsMs.take(6).forEachIndexed { i, lapMs ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(ElevatedSlate)
                                            .padding(horizontal = 12.dp, vertical = 8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                    ) {
                                        Text(
                                            text = "Круг #${tools.stopwatch.lapsMs.size - i}",
                                            color = TextSecondary,
                                            fontFamily = ManropeFamily,
                                            fontSize = 13.sp,
                                        )
                                        Text(
                                            text = formatStopwatchMs(lapMs),
                                            color = accent,
                                            fontFamily = JetBrainsMonoFamily,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            2 -> {
                val rows = listOf(
                    listOf("C", "⌫", "%", "÷"),
                    listOf("7", "8", "9", "×"),
                    listOf("4", "5", "6", "-"),
                    listOf("1", "2", "3", "+"),
                    listOf("+/-", "0", ".", "="),
                )
                Surface(
                    color = MidnightCard,
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, HairlineBorder, RoundedCornerShape(24.dp)),
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(ElevatedSlate)
                                .padding(16.dp),
                            contentAlignment = Alignment.CenterEnd,
                        ) {
                            Text(
                                text = tools.calculator.error ?: tools.calculator.display,
                                color = if (tools.calculator.error != null) CoralAlert else TextPrimary,
                                fontFamily = JetBrainsMonoFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 30.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                        rows.forEach { row ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                row.forEach { key ->
                                    val isEq = key == "="
                                    val isOp = key in setOf("÷", "×", "-", "+", "%", "C", "⌫")
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(52.dp)
                                            .clip(RoundedCornerShape(14.dp))
                                            .background(
                                                when {
                                                    isEq -> accent
                                                    isOp -> ElevatedSlate
                                                    else -> Color(0xFF232838)
                                                }
                                            )
                                            .clickable { onCalcKey(key) },
                                        contentAlignment = Alignment.Center,
                                    ) {
                                        Text(
                                            text = key,
                                            color = if (isEq) Color.Black else if (isOp) accent else TextPrimary,
                                            fontFamily = JetBrainsMonoFamily,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 18.sp,
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            3 -> {
                Surface(
                    color = MidnightCard,
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, HairlineBorder, RoundedCornerShape(24.dp)),
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                    ) {
                        val torchOn = tools.flashlight.isOn
                        val torchSize by animateDpAsState(
                            targetValue = if (torchOn) 120.dp else 104.dp,
                            animationSpec = spring(dampingRatio = 0.65f, stiffness = 400f),
                            label = "torch_size",
                        )
                        val torchBg by animateColorAsState(
                            targetValue = if (torchOn) Color.White else ElevatedSlate,
                            animationSpec = tween(220),
                            label = "torch_bg",
                        )
                        Box(
                            modifier = Modifier
                                .size(torchSize)
                                .clip(CircleShape)
                                .background(torchBg)
                                .border(2.dp, if (torchOn) Color.White else HairlineBorder, CircleShape)
                                .clickable(onClick = onToggleFlashlight),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                imageVector = if (torchOn) Icons.Rounded.FlashlightOn else Icons.Rounded.FlashlightOff,
                                contentDescription = "Фонарик",
                                tint = if (torchOn) Color.Black else TextPrimary,
                                modifier = Modifier.size(44.dp),
                            )
                        }
                        Text(
                            text = when {
                                tools.flashlight.errorMessage != null -> tools.flashlight.errorMessage
                                torchOn -> "Вспышка включена"
                                else -> "Вспышка выключена"
                            },
                            color = if (tools.flashlight.errorMessage != null) CoralAlert else TextPrimary,
                            fontFamily = ManropeFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            textAlign = TextAlign.Center,
                        )
                    }
                }
            }
            }
        }
    }
}

@Composable
fun SettingsSectionScreen(
    settings: IslandSettings,
    permissions: PermissionStatus,
    onUpdateSettings: ((IslandSettings) -> IslandSettings) -> Unit,
    onResetDefaults: () -> Unit,
    onOpenOverlaySettings: () -> Unit,
    onOpenListenerSettings: () -> Unit,
    onRequestPostNotifications: () -> Unit,
    onOpenDndSettings: () -> Unit,
) {
    val accent = MaterialTheme.colorScheme.primary

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // 1. Внешний вид
        Surface(
            color = MidnightCard,
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth().border(1.dp, HairlineBorder, RoundedCornerShape(20.dp)),
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Внешний вид", color = TextPrimary, fontFamily = ManropeFamily, fontWeight = FontWeight.Bold, fontSize = 16.sp)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("Оттенок монохрома", color = TextSecondary, fontFamily = ManropeFamily, fontSize = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        IslandAccent.entries.forEach { item ->
                            val selected = item == settings.accent
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(item.primaryColor)
                                    .then(
                                        if (selected) Modifier.border(2.5.dp, Color.White, CircleShape) else Modifier
                                    )
                                    .clickable { onUpdateSettings { it.copy(accent = item) } },
                            )
                        }
                    }
                }

                LabeledSlider(
                    title = "Прозрачность капсулы",
                    valueLabel = "${(settings.capsuleOpacity * 100).roundToInt()}%",
                    value = settings.capsuleOpacity,
                    valueRange = 0.65f..1.0f,
                    accent = accent,
                    onValueChange = { v -> onUpdateSettings { it.copy(capsuleOpacity = v) } },
                )

                SwitchSettingRow(
                    title = "Неоновая окантовка",
                    subtitle = "Тонкое свечение контура вокруг капсулы",
                    checked = settings.glowBorderEnabled,
                    onCheckedChange = { v -> onUpdateSettings { it.copy(glowBorderEnabled = v) } },
                )

                SwitchSettingRow(
                    title = "Время в режиме ожидания",
                    subtitle = "Показывать текущие часы внутри свёрнутого острова",
                    checked = settings.showIdleClock,
                    onCheckedChange = { v -> onUpdateSettings { it.copy(showIdleClock = v) } },
                )
            }
        }

        // 2. Анимации
        Surface(
            color = MidnightCard,
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth().border(1.dp, HairlineBorder, RoundedCornerShape(20.dp)),
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Анимации", color = TextPrimary, fontFamily = ManropeFamily, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IslandAnimStyle.entries.forEach { style ->
                        val selected = style == settings.animStyle
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (selected) accent else ElevatedSlate)
                                .clickable { onUpdateSettings { it.copy(animStyle = style) } }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                text = style.titleRu,
                                color = if (selected) Color.Black else TextPrimary,
                                fontFamily = ManropeFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                            )
                        }
                    }
                }

                LabeledSlider(
                    title = "Скорость анимации",
                    valueLabel = String.format(java.util.Locale.US, "%.1fx", settings.animSpeedMultiplier),
                    value = settings.animSpeedMultiplier,
                    valueRange = 0.6f..1.6f,
                    accent = accent,
                    onValueChange = { v -> onUpdateSettings { it.copy(animSpeedMultiplier = v) } },
                )

                SwitchSettingRow(
                    title = "Пульсация эквалайзера",
                    subtitle = "Живые волны звука при воспроизведении музыки",
                    checked = settings.equalizerPulseEnabled,
                    onCheckedChange = { v -> onUpdateSettings { it.copy(equalizerPulseEnabled = v) } },
                )
            }
        }

        // 3. Размер и положение острова
        Surface(
            color = MidnightCard,
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth().border(1.dp, HairlineBorder, RoundedCornerShape(20.dp)),
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Размер и положение", color = TextPrimary, fontFamily = ManropeFamily, fontWeight = FontWeight.Bold, fontSize = 16.sp)

                LabeledSlider(
                    title = "Ширина капсулы",
                    valueLabel = "${settings.collapsedWidthDp} dp",
                    value = settings.collapsedWidthDp.toFloat(),
                    valueRange = 112f..260f,
                    accent = accent,
                    onValueChange = { v -> onUpdateSettings { it.copy(collapsedWidthDp = v.roundToInt()) } },
                )
                LabeledSlider(
                    title = "Высота капсулы",
                    valueLabel = "${settings.collapsedHeightDp} dp",
                    value = settings.collapsedHeightDp.toFloat(),
                    valueRange = 26f..48f,
                    accent = accent,
                    onValueChange = { v -> onUpdateSettings { it.copy(collapsedHeightDp = v.roundToInt()) } },
                )
                LabeledSlider(
                    title = "Скругление краёв",
                    valueLabel = "${settings.cornerRadiusDp} dp",
                    value = settings.cornerRadiusDp.toFloat(),
                    valueRange = 12f..32f,
                    accent = accent,
                    onValueChange = { v -> onUpdateSettings { it.copy(cornerRadiusDp = v.roundToInt()) } },
                )
                LabeledSlider(
                    title = "Ширина раскрытой панели",
                    valueLabel = "${settings.expandedWidthDp} dp",
                    value = settings.expandedWidthDp.toFloat(),
                    valueRange = 300f..440f,
                    accent = accent,
                    onValueChange = { v -> onUpdateSettings { it.copy(expandedWidthDp = v.roundToInt()) } },
                )
                LabeledSlider(
                    title = "Отступ сверху",
                    valueLabel = "${settings.topOffsetDp} dp",
                    value = settings.topOffsetDp.toFloat(),
                    valueRange = 0f..96f,
                    accent = accent,
                    onValueChange = { v -> onUpdateSettings { it.copy(topOffsetDp = v.roundToInt()) } },
                )
                LabeledSlider(
                    title = "Смещение по горизонтали",
                    valueLabel = "${settings.horizontalOffsetDp} dp",
                    value = settings.horizontalOffsetDp.toFloat(),
                    valueRange = -120f..120f,
                    accent = accent,
                    onValueChange = { v -> onUpdateSettings { it.copy(horizontalOffsetDp = v.roundToInt()) } },
                )

                Text("Автосворачивание", color = TextSecondary, fontFamily = ManropeFamily, fontSize = 13.sp)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(0 to "Выкл", 5 to "5с", 10 to "10с", 15 to "15с", 30 to "30с").forEach { (sec, label) ->
                        val selected = settings.autoCollapseSeconds == sec
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (selected) accent else ElevatedSlate)
                                .clickable { onUpdateSettings { it.copy(autoCollapseSeconds = sec) } }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                text = label,
                                color = if (selected) Color.Black else TextPrimary,
                                fontFamily = JetBrainsMonoFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                            )
                        }
                    }
                }
            }
        }

        // 4. Разрешения системы
        Surface(
            color = MidnightCard,
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth().border(1.dp, HairlineBorder, RoundedCornerShape(20.dp)),
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Системные разрешения", color = TextPrimary, fontFamily = ManropeFamily, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                PermissionActionRow(
                    title = "Поверх других приложений",
                    granted = permissions.canDrawOverlays,
                    onClick = onOpenOverlaySettings,
                )
                PermissionActionRow(
                    title = "Доступ к уведомлениям (MediaSession)",
                    granted = permissions.isNotificationListenerEnabled,
                    onClick = onOpenListenerSettings,
                )
                PermissionActionRow(
                    title = "Показ уведомлений службы",
                    granted = permissions.isPostNotificationsGranted,
                    onClick = onRequestPostNotifications,
                )
                PermissionActionRow(
                    title = "Управление «Не беспокоить» (Game Turbo)",
                    granted = permissions.isDndPolicyGranted,
                    onClick = onOpenDndSettings,
                )
            }
        }

        FilledTonalButton(
            onClick = onResetDefaults,
            modifier = Modifier.fillMaxWidth().height(48.dp),
            colors = ButtonDefaults.filledTonalButtonColors(
                containerColor = ElevatedSlate,
                contentColor = TextPrimary,
            ),
        ) {
            Icon(Icons.Rounded.Restore, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("Сбросить настройки по умолчанию", fontFamily = ManropeFamily, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun LabeledSlider(
    title: String,
    valueLabel: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    accent: Color,
    onValueChange: (Float) -> Unit,
) {
    Column {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, color = TextSecondary, fontFamily = ManropeFamily, fontSize = 13.sp)
            Text(valueLabel, color = accent, fontFamily = JetBrainsMonoFamily, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRange,
            colors = SliderDefaults.colors(
                thumbColor = accent,
                activeTrackColor = accent,
                inactiveTrackColor = ElevatedSlate,
            ),
        )
    }
}

@Composable
private fun PermissionActionRow(
    title: String,
    granted: Boolean,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(ElevatedSlate)
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f),
        ) {
            Icon(
                imageVector = if (granted) Icons.Rounded.CheckCircle else Icons.Rounded.ErrorOutline,
                contentDescription = null,
                tint = if (granted) EmeraldMint else AmberThermal,
                modifier = Modifier.size(20.dp),
            )
            Text(
                text = title,
                color = TextPrimary,
                fontFamily = ManropeFamily,
                fontSize = 13.sp,
                maxLines = 2,
            )
        }
        Text(
            text = if (granted) "Выдано" else "Выдать",
            color = if (granted) EmeraldMint else AmberThermal,
            fontFamily = ManropeFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
        )
    }
}
