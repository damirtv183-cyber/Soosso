package com.example.ui.screens

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.CleaningServices
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.RocketLaunch
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.Thermostat
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BatteryState
import com.example.data.model.InstalledAppInfo
import com.example.data.model.IslandSettings
import com.example.data.model.NetworkState
import com.example.data.model.PermissionStatus
import com.example.data.model.SystemState
import com.example.ui.island.SpeedSparkline
import com.example.ui.theme.AmberThermal
import com.example.ui.theme.CoralAlert
import com.example.ui.theme.ElevatedSlate
import com.example.ui.theme.EmeraldMint
import com.example.ui.theme.HairlineBorder
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.ManropeFamily
import com.example.ui.theme.MidnightCard
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.util.formatSpeedBytesPerSec
import java.util.Locale

@Composable
fun BatterySectionScreen(battery: BatteryState) {
    val accent = MaterialTheme.colorScheme.primary
    val chargeColor = if (battery.isCharging) EmeraldMint else accent
    val animatedBatterySweep by animateFloatAsState(
        targetValue = (battery.levelPercent / 100f) * 360f,
        animationSpec = spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessLow),
        label = "battery_sweep",
    )

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Surface(
            color = MidnightCard,
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, HairlineBorder, RoundedCornerShape(24.dp)),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(20.dp),
            ) {
                Box(
                    modifier = Modifier.size(104.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Canvas(modifier = Modifier.size(104.dp)) {
                        val stroke = 10.dp.toPx()
                        drawArc(
                            color = ElevatedSlate,
                            startAngle = -90f,
                            sweepAngle = 360f,
                            useCenter = false,
                            style = Stroke(width = stroke, cap = StrokeCap.Round),
                        )
                        drawArc(
                            color = chargeColor,
                            startAngle = -90f,
                            sweepAngle = animatedBatterySweep,
                            useCenter = false,
                            style = Stroke(width = stroke, cap = StrokeCap.Round),
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        if (battery.isCharging) {
                            Icon(
                                Icons.Rounded.BatteryChargingFull,
                                contentDescription = "Зарядка",
                                tint = EmeraldMint,
                                modifier = Modifier.size(20.dp),
                            )
                        }
                        Text(
                            text = "${battery.levelPercent}%",
                            color = TextPrimary,
                            fontFamily = JetBrainsMonoFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 24.sp,
                        )
                    }
                }

                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = battery.statusRu,
                        color = chargeColor,
                        fontFamily = ManropeFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 19.sp,
                    )
                    Text(
                        text = "Источник: ${battery.chargeSourceRu}",
                        color = TextSecondary,
                        fontFamily = ManropeFamily,
                        fontSize = 13.sp,
                    )
                    Text(
                        text = "Технология: ${battery.technology}",
                        color = TextMuted,
                        fontFamily = JetBrainsMonoFamily,
                        fontSize = 12.sp,
                    )
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            MetricCard(
                label = "Напряжение",
                value = String.format(Locale.US, "%.2f В", battery.voltageV),
                accent = accent,
                modifier = Modifier.weight(1f),
            )
            MetricCard(
                label = "Ток",
                value = "${battery.currentMa} мА",
                accent = chargeColor,
                modifier = Modifier.weight(1f),
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            MetricCard(
                label = "Температура",
                value = String.format(Locale.US, "%.1f °C", battery.temperatureC),
                accent = if (battery.temperatureC >= 40f) AmberThermal else EmeraldMint,
                modifier = Modifier.weight(1f),
            )
            MetricCard(
                label = "Состояние",
                value = battery.healthRu,
                accent = accent,
                modifier = Modifier.weight(1f),
            )
        }
    }
}

@Composable
fun SystemSectionScreen(
    system: SystemState,
    onRefresh: () -> Unit,
    onClearCache: () -> Unit,
) {
    val accent = MaterialTheme.colorScheme.primary
    val tempColor = when {
        system.batteryTempC >= 43f -> CoralAlert
        system.batteryTempC >= 37f -> AmberThermal
        else -> EmeraldMint
    }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        SectionHeaderCard(
            title = "Система и память",
            subtitle = "Живые датчики температуры батареи, доступной ОЗУ и накопителя",
            trailing = {
                FilledTonalButton(
                    onClick = onRefresh,
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = ElevatedSlate,
                        contentColor = accent,
                    ),
                ) {
                    Icon(Icons.Rounded.Refresh, contentDescription = "Обновить", modifier = Modifier.size(16.dp))
                }
            },
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Surface(
                color = MidnightCard,
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, HairlineBorder, RoundedCornerShape(20.dp)),
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Rounded.Thermostat, contentDescription = null, tint = tempColor)
                    Text(
                        text = String.format(Locale.US, "%.1f °C", system.batteryTempC),
                        color = TextPrimary,
                        fontFamily = JetBrainsMonoFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp,
                    )
                    Text(
                        text = "Батарея: ${system.thermalStatusRu}",
                        color = tempColor,
                        fontFamily = ManropeFamily,
                        fontSize = 12.sp,
                    )
                }
            }

            Surface(
                color = MidnightCard,
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, HairlineBorder, RoundedCornerShape(20.dp)),
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Rounded.Memory, contentDescription = null, tint = accent)
                    Text(
                        text = "${system.availableRamMb} МБ",
                        color = TextPrimary,
                        fontFamily = JetBrainsMonoFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp,
                    )
                    Text(
                        text = "Доступно ОЗУ",
                        color = TextSecondary,
                        fontFamily = ManropeFamily,
                        fontSize = 12.sp,
                    )
                }
            }
        }

        Surface(
            color = MidnightCard,
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, HairlineBorder, RoundedCornerShape(20.dp)),
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Использование ОЗУ", color = TextPrimary, fontFamily = ManropeFamily, fontWeight = FontWeight.SemiBold)
                    Text("${system.ramUsagePercent}%", color = accent, fontFamily = JetBrainsMonoFamily, fontWeight = FontWeight.Bold)
                }
                LinearProgressIndicator(
                    progress = { system.ramUsagePercent / 100f },
                    color = accent,
                    trackColor = ElevatedSlate,
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                )
                Text(
                    text = "Занято ${system.totalRamMb - system.availableRamMb} МБ из ${system.totalRamMb} МБ",
                    color = TextSecondary,
                    fontFamily = JetBrainsMonoFamily,
                    fontSize = 12.sp,
                )

                Spacer(Modifier.height(4.dp))
                val usedStorageGb = (system.totalStorageGb - system.availableStorageGb).coerceAtLeast(0f)
                val storageRatio = if (system.totalStorageGb > 0f) (usedStorageGb / system.totalStorageGb).coerceIn(0f, 1f) else 0f
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Rounded.Storage, contentDescription = null, tint = EmeraldMint, modifier = Modifier.size(16.dp))
                        Text("Память устройства", color = TextPrimary, fontFamily = ManropeFamily, fontWeight = FontWeight.SemiBold)
                    }
                    Text(
                        "${String.format(Locale.US, "%.1f", system.availableStorageGb)} ГБ своб.",
                        color = EmeraldMint,
                        fontFamily = JetBrainsMonoFamily,
                        fontSize = 12.sp,
                    )
                }
                LinearProgressIndicator(
                    progress = { storageRatio },
                    color = EmeraldMint,
                    trackColor = ElevatedSlate,
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                )
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Ядра CPU: ${system.cpuCores}", color = TextMuted, fontFamily = JetBrainsMonoFamily, fontSize = 11.sp)
                    Text("Аптайм: ${system.uptimeFormatted}", color = TextMuted, fontFamily = JetBrainsMonoFamily, fontSize = 11.sp)
                }
            }
        }

        Surface(
            color = MidnightCard,
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, HairlineBorder, RoundedCornerShape(20.dp)),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Column {
                    Text("Кэш приложения Tira", color = TextPrimary, fontFamily = ManropeFamily, fontWeight = FontWeight.SemiBold)
                    Text("${system.appCacheKb} КБ", color = TextSecondary, fontFamily = JetBrainsMonoFamily, fontSize = 12.sp)
                }
                Button(
                    onClick = onClearCache,
                    colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color.Black),
                ) {
                    Icon(Icons.Rounded.CleaningServices, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Очистить", fontFamily = ManropeFamily, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun GamingSectionScreen(
    settings: IslandSettings,
    system: SystemState,
    permissions: PermissionStatus,
    games: List<InstalledAppInfo>,
    onToggleGameTurbo: (Boolean) -> Unit,
    onToggleDnd: (Boolean) -> Unit,
    onToggleKeepScreen: (Boolean) -> Unit,
    onToggleCompactHud: (Boolean) -> Unit,
    onLaunchSystemGameTurbo: () -> Unit,
    onLaunchGame: (String) -> Unit,
    onOpenDndSettings: () -> Unit,
) {
    val accent = MaterialTheme.colorScheme.primary

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Surface(
            color = MidnightCard,
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    width = 1.dp,
                    color = if (settings.gameTurboActive) EmeraldMint else HairlineBorder,
                    shape = RoundedCornerShape(24.dp),
                ),
        ) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background((if (settings.gameTurboActive) EmeraldMint else accent).copy(alpha = 0.16f)),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                Icons.Rounded.SportsEsports,
                                contentDescription = "Game Turbo",
                                tint = if (settings.gameTurboActive) EmeraldMint else accent,
                            )
                        }
                        Column {
                            Text("Game Turbo", color = TextPrimary, fontFamily = ManropeFamily, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text(
                                if (settings.gameTurboActive) "Турбо-профиль активен" else "Быстрый игровой буст и HUD",
                                color = if (settings.gameTurboActive) EmeraldMint else TextSecondary,
                                fontFamily = ManropeFamily,
                                fontSize = 12.sp,
                            )
                        }
                    }
                    Switch(
                        checked = settings.gameTurboActive,
                        onCheckedChange = onToggleGameTurbo,
                        colors = SwitchDefaults.colors(checkedThumbColor = Color.Black, checkedTrackColor = EmeraldMint),
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MetricCard("Температура", "${String.format(Locale.US, "%.1f", system.batteryTempC)} °C", AmberThermal, Modifier.weight(1f))
                    MetricCard("Свободно ОЗУ", "${system.availableRamMb} МБ", accent, Modifier.weight(1f))
                }

                Button(
                    onClick = onLaunchSystemGameTurbo,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldMint, contentColor = Color.Black),
                ) {
                    Icon(Icons.Rounded.RocketLaunch, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Быстрый запуск Game Turbo", fontFamily = ManropeFamily, fontWeight = FontWeight.Bold)
                }
            }
        }

        Surface(
            color = MidnightCard,
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, HairlineBorder, RoundedCornerShape(20.dp)),
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Параметры Game Turbo", color = TextPrimary, fontFamily = ManropeFamily, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                SwitchSettingRow(
                    title = "Режим «Не беспокоить»",
                    subtitle = if (permissions.isDndPolicyGranted) "Разрешение выдано" else "Нажмите для выдачи доступа DND",
                    checked = settings.gameTurboDnd,
                    onCheckedChange = {
                        if (!permissions.isDndPolicyGranted) onOpenDndSettings() else onToggleDnd(it)
                    },
                )
                SwitchSettingRow(
                    title = "Не выключать экран",
                    subtitle = "Удерживать экран активным пока остров включён",
                    checked = settings.gameTurboKeepScreenOn,
                    onCheckedChange = onToggleKeepScreen,
                )
                SwitchSettingRow(
                    title = "Компактный HUD в капсуле",
                    subtitle = "Отображать температуру и заряд в свёрнутом острове",
                    checked = settings.gameTurboCompactHud,
                    onCheckedChange = onToggleCompactHud,
                )
            }
        }

        Surface(
            color = MidnightCard,
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, HairlineBorder, RoundedCornerShape(20.dp)),
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Установленные игры", color = TextPrimary, fontFamily = ManropeFamily, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                if (games.isEmpty()) {
                    Text(
                        text = "Игры на устройстве не обнаружены. Вы можете запускать любые приложения через Лаунчер или активировать Game Turbo кнопкой выше.",
                        color = TextSecondary,
                        fontFamily = ManropeFamily,
                        fontSize = 12.sp,
                    )
                } else {
                    games.forEach { game ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(ElevatedSlate)
                                .clickable { onLaunchGame(game.packageName) }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            if (game.icon != null) {
                                Image(
                                    bitmap = game.icon,
                                    contentDescription = game.label,
                                    modifier = Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)),
                                )
                            }
                            Text(
                                text = game.label,
                                color = TextPrimary,
                                fontFamily = ManropeFamily,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.weight(1f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text("Играть", color = EmeraldMint, fontFamily = ManropeFamily, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NetworkSectionScreen(
    network: NetworkState,
    onOpenInternetPanel: () -> Unit,
) {
    val accent = MaterialTheme.colorScheme.primary

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Surface(
            color = MidnightCard,
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, HairlineBorder, RoundedCornerShape(24.dp)),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(18.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background((if (network.isConnected) accent else CoralAlert).copy(alpha = 0.16f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        Icons.Rounded.Wifi,
                        contentDescription = "Сеть",
                        tint = if (network.isConnected) accent else CoralAlert,
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = network.networkName,
                        color = TextPrimary,
                        fontFamily = ManropeFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = "${network.transportTypeRu} · Сигнал ${network.signalBars}/4",
                        color = TextSecondary,
                        fontFamily = ManropeFamily,
                        fontSize = 12.sp,
                    )
                }
                FilledTonalButton(
                    onClick = onOpenInternetPanel,
                    colors = ButtonDefaults.filledTonalButtonColors(containerColor = ElevatedSlate, contentColor = accent),
                ) {
                    Text("Настроить", fontFamily = ManropeFamily, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SpeedCard(
                title = "Скачивание",
                value = formatSpeedBytesPerSec(network.rxBytesPerSec),
                icon = Icons.Rounded.ArrowDownward,
                color = EmeraldMint,
                modifier = Modifier.weight(1f),
            )
            SpeedCard(
                title = "Отдача",
                value = formatSpeedBytesPerSec(network.txBytesPerSec),
                icon = Icons.Rounded.ArrowUpward,
                color = accent,
                modifier = Modifier.weight(1f),
            )
        }

        Surface(
            color = MidnightCard,
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, HairlineBorder, RoundedCornerShape(20.dp)),
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("График скорости трафика", color = TextPrimary, fontFamily = ManropeFamily, fontWeight = FontWeight.SemiBold)
                    if (network.linkSpeedMbps > 0) {
                        Text(
                            "${network.linkSpeedMbps} Мбит/с",
                            color = accent,
                            fontFamily = JetBrainsMonoFamily,
                            fontSize = 12.sp,
                        )
                    }
                }
                SpeedSparkline(
                    samples = network.speedHistoryRxKbps,
                    lineColor = accent,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(92.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(ElevatedSlate.copy(alpha = 0.6f))
                        .padding(8.dp),
                )
            }
        }
    }
}

@Composable
private fun SpeedCard(
    title: String,
    value: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
) {
    Surface(
        color = MidnightCard,
        shape = RoundedCornerShape(20.dp),
        modifier = modifier.border(1.dp, HairlineBorder, RoundedCornerShape(20.dp)),
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
                Text(title, color = TextSecondary, fontFamily = ManropeFamily, fontSize = 12.sp)
            }
            Text(
                text = value,
                color = TextPrimary,
                fontFamily = JetBrainsMonoFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
            )
        }
    }
}

@Composable
fun MetricCard(
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier,
) {
    Surface(
        color = MidnightCard,
        shape = RoundedCornerShape(18.dp),
        modifier = modifier.border(1.dp, HairlineBorder, RoundedCornerShape(18.dp)),
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, color = TextSecondary, fontFamily = ManropeFamily, fontSize = 12.sp)
            Text(
                text = value,
                color = accent,
                fontFamily = JetBrainsMonoFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
            )
        }
    }
}

@Composable
fun SwitchSettingRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, color = TextPrimary, fontFamily = ManropeFamily, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(subtitle, color = TextSecondary, fontFamily = ManropeFamily, fontSize = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
