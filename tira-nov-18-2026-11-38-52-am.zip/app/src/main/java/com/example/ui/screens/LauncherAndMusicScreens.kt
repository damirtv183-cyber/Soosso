package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.InstalledAppInfo
import com.example.data.model.MusicState
import com.example.data.repository.SettingsRepository
import com.example.ui.theme.CoralAlert
import com.example.ui.theme.ElevatedSlate
import com.example.ui.theme.EmeraldMint
import com.example.ui.theme.HairlineBorder
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.ManropeFamily
import com.example.ui.theme.MidnightCard
import com.example.ui.theme.SmokedSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.util.formatDurationMs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LauncherSectionScreen(
    pinnedApps: List<InstalledAppInfo>,
    allApps: List<InstalledAppInfo>,
    onMoveApp: (String, Int) -> Unit,
    onRemoveApp: (String) -> Unit,
    onTogglePinApp: (String) -> Unit,
    onLaunchApp: (String) -> Unit,
    onRefreshApps: () -> Unit,
) {
    val accent = MaterialTheme.colorScheme.primary
    var showAppPicker by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        SectionHeaderCard(
            title = "Лаунчер · 8 слотов",
            subtitle = "Закрепите до ${SettingsRepository.MAX_PINNED_APPS} приложений, меняйте порядок или запускайте в одно касание",
            trailing = {
                FilledTonalButton(
                    onClick = {
                        onRefreshApps()
                        showAppPicker = true
                    },
                    modifier = Modifier.testTag("launcher_add_app_button"),
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = accent.copy(alpha = 0.16f),
                        contentColor = accent,
                    ),
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Выбрать", fontFamily = ManropeFamily, fontWeight = FontWeight.SemiBold)
                }
            },
        )

        // 8 slots list
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            for (slotIndex in 0 until SettingsRepository.MAX_PINNED_APPS) {
                val app = pinnedApps.getOrNull(slotIndex)
                if (app != null) {
                    PinnedAppRowCard(
                        slotNumber = slotIndex + 1,
                        app = app,
                        canMoveUp = slotIndex > 0,
                        canMoveDown = slotIndex < pinnedApps.lastIndex,
                        accent = accent,
                        onMoveUp = { onMoveApp(app.packageName, -1) },
                        onMoveDown = { onMoveApp(app.packageName, 1) },
                        onRemove = { onRemoveApp(app.packageName) },
                        onLaunch = { onLaunchApp(app.packageName) },
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(60.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .background(MidnightCard.copy(alpha = 0.65f))
                            .border(1.dp, HairlineBorder, RoundedCornerShape(18.dp))
                            .clickable {
                                onRefreshApps()
                                showAppPicker = true
                            }
                            .padding(horizontal = 16.dp),
                        contentAlignment = Alignment.CenterStart,
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            Text(
                                text = "0${slotIndex + 1}",
                                color = TextMuted,
                                fontFamily = JetBrainsMonoFamily,
                                fontSize = 13.sp,
                            )
                            Icon(Icons.Rounded.Add, contentDescription = null, tint = accent, modifier = Modifier.size(18.dp))
                            Text(
                                text = "Свободный слот — нажмите, чтобы добавить приложение",
                                color = TextSecondary,
                                fontFamily = ManropeFamily,
                                fontSize = 13.sp,
                            )
                        }
                    }
                }
            }
        }
    }

    if (showAppPicker) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        val pinnedSet = pinnedApps.map { it.packageName }.toSet()
        val filteredApps = remember(allApps, searchQuery) {
            if (searchQuery.isBlank()) allApps
            else allApps.filter {
                it.label.contains(searchQuery, ignoreCase = true) ||
                    it.packageName.contains(searchQuery, ignoreCase = true)
            }
        }

        ModalBottomSheet(
            onDismissRequest = { showAppPicker = false },
            sheetState = sheetState,
            containerColor = SmokedSurface,
            contentColor = TextPrimary,
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = "Выбор приложений (${pinnedApps.size}/${SettingsRepository.MAX_PINNED_APPS})",
                        fontFamily = ManropeFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = TextPrimary,
                    )
                    IconButton(onClick = { showAppPicker = false }) {
                        Icon(Icons.Rounded.Close, contentDescription = "Закрыть", tint = TextSecondary)
                    }
                }

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Поиск по названию или пакету", fontFamily = ManropeFamily) },
                    leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = accent,
                        unfocusedBorderColor = HairlineBorder,
                        focusedContainerColor = MidnightCard,
                        unfocusedContainerColor = MidnightCard,
                    ),
                    modifier = Modifier.fillMaxWidth(),
                )

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(380.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(filteredApps, key = { it.packageName }) { app ->
                        val isPinned = app.packageName in pinnedSet
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (isPinned) accent.copy(alpha = 0.14f) else MidnightCard)
                                .border(
                                    width = 1.dp,
                                    color = if (isPinned) accent else HairlineBorder,
                                    shape = RoundedCornerShape(16.dp),
                                )
                                .clickable { onTogglePinApp(app.packageName) }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            if (app.icon != null) {
                                Image(
                                    bitmap = app.icon,
                                    contentDescription = app.label,
                                    modifier = Modifier.size(38.dp).clip(RoundedCornerShape(10.dp)),
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(ElevatedSlate),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    Icon(Icons.Rounded.Apps, contentDescription = null, tint = accent)
                                }
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = app.label,
                                    color = TextPrimary,
                                    fontFamily = ManropeFamily,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 14.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                Text(
                                    text = if (app.isGame) "Игра · ${app.packageName}" else app.packageName,
                                    color = TextMuted,
                                    fontFamily = JetBrainsMonoFamily,
                                    fontSize = 10.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                            if (isPinned) {
                                Icon(Icons.Rounded.CheckCircle, contentDescription = "Закреплено", tint = accent)
                            } else {
                                Icon(Icons.Rounded.Add, contentDescription = "Добавить", tint = TextSecondary)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PinnedAppRowCard(
    slotNumber: Int,
    app: InstalledAppInfo,
    canMoveUp: Boolean,
    canMoveDown: Boolean,
    accent: Color,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onRemove: () -> Unit,
    onLaunch: () -> Unit,
) {
    Surface(
        color = MidnightCard,
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, HairlineBorder, RoundedCornerShape(18.dp)),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(
                text = "0$slotNumber",
                color = accent,
                fontFamily = JetBrainsMonoFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
            )
            if (app.icon != null) {
                Image(
                    bitmap = app.icon,
                    contentDescription = app.label,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable(onClick = onLaunch),
                )
            }
            Column(
                modifier = Modifier
                    .weight(1f)
                    .clickable(onClick = onLaunch),
            ) {
                Text(
                    text = app.label,
                    color = TextPrimary,
                    fontFamily = ManropeFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = app.packageName,
                    color = TextMuted,
                    fontFamily = JetBrainsMonoFamily,
                    fontSize = 10.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            IconButton(
                onClick = onMoveUp,
                enabled = canMoveUp,
                modifier = Modifier.size(48.dp),
            ) {
                Icon(
                    Icons.AutoMirrored.Rounded.KeyboardArrowLeft,
                    contentDescription = "Переместить выше",
                    tint = if (canMoveUp) TextPrimary else TextMuted.copy(alpha = 0.4f),
                )
            }
            IconButton(
                onClick = onMoveDown,
                enabled = canMoveDown,
                modifier = Modifier.size(48.dp),
            ) {
                Icon(
                    Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                    contentDescription = "Переместить ниже",
                    tint = if (canMoveDown) TextPrimary else TextMuted.copy(alpha = 0.4f),
                )
            }
            IconButton(
                onClick = onLaunch,
                modifier = Modifier.size(48.dp),
            ) {
                Icon(Icons.AutoMirrored.Rounded.OpenInNew, contentDescription = "Открыть", tint = accent)
            }
            IconButton(
                onClick = onRemove,
                modifier = Modifier.size(48.dp),
            ) {
                Icon(Icons.Rounded.Close, contentDescription = "Удалить", tint = CoralAlert)
            }
        }
    }
}

@Composable
fun MusicSectionScreen(
    music: MusicState,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrev: () -> Unit,
    onSeek: (Long) -> Unit,
    onRequestListener: () -> Unit,
    onRefreshSessions: () -> Unit,
) {
    val accent = MaterialTheme.colorScheme.primary

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        if (!music.listenerConnected) {
            Surface(
                color = CoralAlert.copy(alpha = 0.12f),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CoralAlert.copy(alpha = 0.45f), RoundedCornerShape(20.dp)),
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Icon(Icons.Rounded.NotificationsActive, contentDescription = null, tint = CoralAlert)
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Требуется доступ к уведомлениям",
                            color = TextPrimary,
                            fontFamily = ManropeFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                        )
                        Text(
                            text = "Нужен для чтения MediaSession: обложки, названия треков, прогресса и кнопок управления.",
                            color = TextSecondary,
                            fontFamily = ManropeFamily,
                            fontSize = 12.sp,
                        )
                    }
                    Button(
                        onClick = onRequestListener,
                        colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color.Black),
                    ) {
                        Text("Включить", fontFamily = ManropeFamily, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Surface(
            color = MidnightCard,
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, HairlineBorder, RoundedCornerShape(24.dp)),
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                val art = music.albumArt
                if (art != null) {
                    Image(
                        bitmap = art.asImageBitmap(),
                        contentDescription = "Обложка альбома",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(190.dp)
                            .clip(RoundedCornerShape(24.dp)),
                    )
                } else {
                    Image(
                        painter = painterResource(id = R.drawable.img_default_album_art),
                        contentDescription = "Обложка по умолчанию",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(190.dp)
                            .clip(RoundedCornerShape(24.dp)),
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = music.title,
                        color = TextPrimary,
                        fontFamily = ManropeFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = music.artist,
                        color = TextSecondary,
                        fontFamily = ManropeFamily,
                        fontSize = 14.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    if (music.sourceAppName.isNotBlank()) {
                        Spacer(Modifier.height(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(999.dp))
                                .background(accent.copy(alpha = 0.16f))
                                .padding(horizontal = 12.dp, vertical = 4.dp),
                        ) {
                            Text(
                                text = music.sourceAppName,
                                color = accent,
                                fontFamily = ManropeFamily,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 11.sp,
                            )
                        }
                    }
                }

                val duration = music.durationMs.coerceAtLeast(1L)
                val progress = (music.positionMs.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
                Column(modifier = Modifier.fillMaxWidth()) {
                    Slider(
                        value = progress,
                        onValueChange = { ratio ->
                            if (music.hasActiveSession && music.durationMs > 0L) {
                                onSeek((ratio * music.durationMs).toLong())
                            }
                        },
                        colors = SliderDefaults.colors(
                            thumbColor = accent,
                            activeTrackColor = accent,
                            inactiveTrackColor = ElevatedSlate,
                        ),
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(
                            formatDurationMs(music.positionMs),
                            color = TextSecondary,
                            fontFamily = JetBrainsMonoFamily,
                            fontSize = 12.sp,
                        )
                        Text(
                            formatDurationMs(music.durationMs),
                            color = TextSecondary,
                            fontFamily = JetBrainsMonoFamily,
                            fontSize = 12.sp,
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = onPrev, modifier = Modifier.size(56.dp)) {
                        Icon(
                            Icons.Rounded.SkipPrevious,
                            contentDescription = "Предыдущий",
                            tint = TextPrimary,
                            modifier = Modifier.size(32.dp),
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(68.dp)
                            .clip(CircleShape)
                            .background(accent)
                            .clickable(onClick = onPlayPause)
                            .testTag("music_play_pause_button"),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            imageVector = if (music.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            contentDescription = if (music.isPlaying) "Пауза" else "Воспроизвести",
                            tint = Color.Black,
                            modifier = Modifier.size(36.dp),
                        )
                    }
                    IconButton(onClick = onNext, modifier = Modifier.size(56.dp)) {
                        Icon(
                            Icons.Rounded.SkipNext,
                            contentDescription = "Следующий",
                            tint = TextPrimary,
                            modifier = Modifier.size(32.dp),
                        )
                    }
                }

                FilledTonalButton(
                    onClick = onRefreshSessions,
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = ElevatedSlate,
                        contentColor = TextPrimary,
                    ),
                ) {
                    Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Обновить активную MediaSession", fontFamily = ManropeFamily, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun SectionHeaderCard(
    title: String,
    subtitle: String,
    trailing: (@Composable () -> Unit)? = null,
) {
    Surface(
        color = MidnightCard,
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, HairlineBorder, RoundedCornerShape(20.dp)),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = TextPrimary,
                    fontFamily = ManropeFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    color = TextSecondary,
                    fontFamily = ManropeFamily,
                    fontSize = 12.sp,
                )
            }
            if (trailing != null) {
                trailing()
            }
        }
    }
}
