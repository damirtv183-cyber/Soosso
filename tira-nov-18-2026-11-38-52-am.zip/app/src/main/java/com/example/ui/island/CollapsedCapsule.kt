package com.example.ui.island

import android.text.format.DateFormat
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.FlashlightOn
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.BatteryState
import com.example.data.model.IslandSettings
import com.example.data.model.MusicState
import com.example.data.model.NotificationBanner
import com.example.data.model.SystemState
import com.example.data.model.ToolsState
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.ManropeFamily
import com.example.ui.theme.PlatinumSilver
import com.example.ui.theme.PureWhite
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.util.formatStopwatchMs
import com.example.ui.util.formatTimerSeconds
import kotlinx.coroutines.delay
import java.util.Date

@Composable
fun CollapsedCapsuleContent(
    settings: IslandSettings,
    music: MusicState,
    battery: BatteryState,
    system: SystemState,
    tools: ToolsState,
    banner: NotificationBanner?,
    modifier: Modifier = Modifier,
) {
    var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) {
            nowMs = System.currentTimeMillis()
            delay(15_000L)
        }
    }

    val showRecentBanner = banner != null && (nowMs - banner.timestampMs) < 5500L
    val accent = settings.accent.primaryColor

    val modeKey = when {
        showRecentBanner -> "banner"
        music.hasActiveSession && music.isPlaying -> "music"
        tools.timer.isRunning || tools.timer.isFinished -> "timer"
        tools.stopwatch.isRunning -> "stopwatch"
        tools.flashlight.isOn -> "torch"
        settings.gameTurboActive && settings.gameTurboCompactHud -> "turbo"
        else -> "idle"
    }

    AnimatedContent(
        targetState = modeKey,
        transitionSpec = {
            fadeIn(tween(180)) togetherWith fadeOut(tween(140))
        },
        label = "collapsed_capsule_mode",
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp),
    ) { mode ->
        when (mode) {
            "banner" -> {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(
                        imageVector = Icons.Rounded.NotificationsActive,
                        contentDescription = "Уведомление",
                        tint = accent,
                        modifier = Modifier.size(15.dp),
                    )
                    Text(
                        text = banner?.title ?: "Уведомление",
                        color = TextPrimary,
                        fontFamily = ManropeFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                }
            }

            "music" -> {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    val art = music.albumArt
                    if (art != null) {
                        Image(
                            bitmap = art.asImageBitmap(),
                            contentDescription = "Обложка",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(20.dp)
                                .clip(CircleShape),
                        )
                    } else {
                        Image(
                            painter = painterResource(id = R.drawable.img_default_album_art),
                            contentDescription = "Обложка",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(20.dp)
                                .clip(CircleShape),
                        )
                    }
                    Text(
                        text = music.title,
                        color = TextPrimary,
                        fontFamily = ManropeFamily,
                        fontWeight = FontWeight.Medium,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                    MiniEqualizerBars(
                        color = accent,
                        animate = settings.equalizerPulseEnabled,
                    )
                }
            }

            "timer" -> {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Timer,
                            contentDescription = "Таймер",
                            tint = if (tools.timer.isFinished) PureWhite else accent,
                            modifier = Modifier.size(15.dp),
                        )
                        Text(
                            text = if (tools.timer.isFinished) "Время!" else "Таймер",
                            color = TextSecondary,
                            fontFamily = ManropeFamily,
                            fontSize = 11.sp,
                        )
                    }
                    Text(
                        text = formatTimerSeconds(tools.timer.remainingSeconds),
                        color = PureWhite,
                        fontFamily = JetBrainsMonoFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                    )
                }
            }

            "stopwatch" -> {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    BreathingDot(color = PureWhite)
                    Text(
                        text = formatStopwatchMs(tools.stopwatch.elapsedMs),
                        color = PureWhite,
                        fontFamily = JetBrainsMonoFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                    )
                }
            }

            "torch" -> {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Icon(
                        imageVector = Icons.Rounded.FlashlightOn,
                        contentDescription = "Фонарик",
                        tint = PureWhite,
                        modifier = Modifier.size(15.dp),
                    )
                    Text(
                        text = "Свет ВКЛ",
                        color = PureWhite,
                        fontFamily = ManropeFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 11.sp,
                    )
                }
            }

            "turbo" -> {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.SportsEsports,
                            contentDescription = "Game Turbo",
                            tint = PureWhite,
                            modifier = Modifier.size(14.dp),
                        )
                        Text(
                            text = "TURBO",
                            color = PureWhite,
                            fontFamily = JetBrainsMonoFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                        )
                    }
                    Text(
                        text = "${system.batteryTempC.toInt()}° · ${battery.levelPercent}%",
                        color = PlatinumSilver,
                        fontFamily = JetBrainsMonoFamily,
                        fontSize = 11.sp,
                    )
                }
            }

            else -> {
                val timeStr = remember(nowMs) {
                    DateFormat.format("HH:mm", Date(nowMs)).toString()
                }
                Row(
                    modifier = Modifier.fillMaxSize(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        BreathingDot(color = accent)
                        if (settings.showIdleClock) {
                            Text(
                                text = timeStr,
                                color = TextPrimary,
                                fontFamily = JetBrainsMonoFamily,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.sp,
                            )
                        } else {
                            Text(
                                text = "Tira",
                                color = TextPrimary,
                                fontFamily = ManropeFamily,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.sp,
                            )
                        }
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(3.dp),
                    ) {
                        if (battery.isCharging) {
                            Icon(
                                imageVector = Icons.Rounded.BatteryChargingFull,
                                contentDescription = "Зарядка",
                                tint = PureWhite,
                                modifier = Modifier.size(13.dp),
                            )
                        }
                        Text(
                            text = "${battery.levelPercent}%",
                            color = if (battery.isCharging) PureWhite else TextSecondary,
                            fontFamily = JetBrainsMonoFamily,
                            fontWeight = FontWeight.Medium,
                            fontSize = 11.sp,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BreathingDot(
    color: Color,
    modifier: Modifier = Modifier,
) {
    val transition = rememberInfiniteTransition(label = "breathing_dot")
    val alphaState = transition.animateFloat(
        initialValue = 0.45f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "dot_alpha",
    )

    Canvas(modifier = modifier.size(7.dp)) {
        drawCircle(
            color = color.copy(alpha = alphaState.value),
            radius = size.minDimension / 2f,
        )
    }
}

@Composable
fun MiniEqualizerBars(
    color: Color,
    animate: Boolean,
    modifier: Modifier = Modifier,
) {
    val transition = rememberInfiniteTransition(label = "eq")
    val b1 = if (animate) {
        transition.animateFloat(
            initialValue = 0.30f,
            targetValue = 1.0f,
            animationSpec = infiniteRepeatable(tween(420, easing = LinearEasing), RepeatMode.Reverse),
            label = "b1",
        )
    } else null
    val b2 = if (animate) {
        transition.animateFloat(
            initialValue = 0.95f,
            targetValue = 0.25f,
            animationSpec = infiniteRepeatable(tween(340, easing = LinearEasing), RepeatMode.Reverse),
            label = "b2",
        )
    } else null
    val b3 = if (animate) {
        transition.animateFloat(
            initialValue = 0.45f,
            targetValue = 0.92f,
            animationSpec = infiniteRepeatable(tween(490, easing = LinearEasing), RepeatMode.Reverse),
            label = "b3",
        )
    } else null
    val b4 = if (animate) {
        transition.animateFloat(
            initialValue = 0.80f,
            targetValue = 0.30f,
            animationSpec = infiniteRepeatable(tween(380, easing = LinearEasing), RepeatMode.Reverse),
            label = "b4",
        )
    } else null

    Canvas(
        modifier = modifier
            .width(15.dp)
            .height(14.dp),
    ) {
        val ratios = floatArrayOf(
            b1?.value ?: 0.45f,
            b2?.value ?: 0.85f,
            b3?.value ?: 0.60f,
            b4?.value ?: 0.75f,
        )
        val barWidth = 2.2.dp.toPx()
        val gap = 2.dp.toPx()
        ratios.forEachIndexed { idx, ratio ->
            val h = size.height * ratio
            val x = idx * (barWidth + gap)
            val y = (size.height - h) / 2f
            drawRoundRect(
                color = color,
                topLeft = Offset(x, y),
                size = Size(barWidth, h),
                cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f),
            )
        }
    }
}
