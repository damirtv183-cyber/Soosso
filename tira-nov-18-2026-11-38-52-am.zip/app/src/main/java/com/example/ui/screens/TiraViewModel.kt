package com.example.ui.screens

import android.app.Application
import android.content.Context
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.TiraApplication
import com.example.data.model.BatteryState
import com.example.data.model.InstalledAppInfo
import com.example.data.model.IslandAccent
import com.example.data.model.IslandAnimStyle
import com.example.data.model.IslandSection
import com.example.data.model.IslandSettings
import com.example.data.model.MusicState
import com.example.data.model.NetworkState
import com.example.data.model.NotificationBanner
import com.example.data.model.PermissionStatus
import com.example.data.model.SystemState
import com.example.data.model.ToolsState
import com.example.data.repository.PermissionHelper
import com.example.data.repository.SettingsRepository
import com.example.service.TiraOverlayService
import com.example.ui.island.IslandCallbacks
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class TiraViewModel(application: Application) : AndroidViewModel(application) {

    private val container = (application as TiraApplication).container
    private val appContext: Context get() = getApplication<Application>()

    private val _selectedSection = MutableStateFlow(IslandSection.LAUNCHER)
    val selectedSection: StateFlow<IslandSection> = _selectedSection.asStateFlow()

    private val _previewExpanded = MutableStateFlow(false)
    val previewExpanded: StateFlow<Boolean> = _previewExpanded.asStateFlow()

    private val _permissions = MutableStateFlow(PermissionHelper.getStatus(appContext))
    val permissions: StateFlow<PermissionStatus> = _permissions.asStateFlow()

    private val _snackbarMessage = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val snackbarMessage: SharedFlow<String> = _snackbarMessage.asSharedFlow()

    val settings: StateFlow<IslandSettings> = container.settingsRepository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), IslandSettings())

    val installedApps: StateFlow<List<InstalledAppInfo>> = container.installedAppsRepository.installedApps
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pinnedApps: StateFlow<List<InstalledAppInfo>> = combine(
        settings,
        installedApps,
    ) { currentSettings, allApps ->
        currentSettings.pinnedPackages.mapNotNull { pkg ->
            allApps.firstOrNull { it.packageName == pkg }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val detectedGames: StateFlow<List<InstalledAppInfo>> = installedApps
        .combine(settings) { apps, _ -> apps.filter { it.isGame } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val music: StateFlow<MusicState> = container.mediaRepository.musicState
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), MusicState())

    val notificationBanner: StateFlow<NotificationBanner?> = container.mediaRepository.latestNotification
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val battery: StateFlow<BatteryState> = container.systemTelemetryRepository.batteryState
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), BatteryState())

    val system: StateFlow<SystemState> = container.systemTelemetryRepository.systemState
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SystemState())

    val network: StateFlow<NetworkState> = container.systemTelemetryRepository.networkState
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), NetworkState())

    val tools: StateFlow<ToolsState> = container.toolsManager.toolsState
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ToolsState())

    val isOverlayServiceRunning: StateFlow<Boolean> = TiraOverlayService.isRunning
    val overlayError: StateFlow<String?> = TiraOverlayService.lastError
    private var pendingStartAfterOverlayGrant = false

    init {
        viewModelScope.launch {
            val current = container.settingsRepository.settingsFlow.first()
            if (current.isOverlayEnabled &&
                PermissionHelper.getStatus(appContext).canDrawOverlays &&
                !TiraOverlayService.isRunning.value
            ) {
                TiraOverlayService.start(appContext)
            }
        }
        viewModelScope.launch {
            TiraOverlayService.lastError.collect { err ->
                if (!err.isNullOrBlank()) {
                    emitMessage(err)
                }
            }
        }
    }

    fun refreshPermissionsAndSessions() {
        val status = PermissionHelper.getStatus(appContext)
        _permissions.value = status
        container.mediaRepository.refreshActiveSessions()
        container.systemTelemetryRepository.refreshSystemMetrics()

        if (pendingStartAfterOverlayGrant && status.canDrawOverlays) {
            pendingStartAfterOverlayGrant = false
            startOverlayInternal()
        }
    }

    fun selectSection(section: IslandSection) {
        _selectedSection.value = section
    }

    fun handleIncomingSectionIntent(intent: Intent?) {
        val raw = intent?.getStringExtra(TiraOverlayService.EXTRA_TARGET_SECTION) ?: return
        runCatching { IslandSection.valueOf(raw) }.getOrNull()?.let {
            _selectedSection.value = it
        }
    }

    fun togglePreviewExpanded() {
        _previewExpanded.value = !_previewExpanded.value
    }

    fun setPreviewExpanded(expanded: Boolean) {
        _previewExpanded.value = expanded
    }

    fun toggleOverlayService(enable: Boolean) {
        refreshPermissionsAndSessions()
        if (enable) {
            if (!_permissions.value.canDrawOverlays) {
                pendingStartAfterOverlayGrant = true
                emitMessage("Включите «Поверх других окон» для Tira, затем вернитесь")
                openOverlayPermissionSettings()
                return
            }
            startOverlayInternal()
        } else {
            pendingStartAfterOverlayGrant = false
            viewModelScope.launch {
                container.settingsRepository.setOverlayEnabled(false)
            }
            TiraOverlayService.stop(appContext)
            emitMessage("Dynamic Island остановлен")
        }
    }

    private fun startOverlayInternal() {
        TiraOverlayService.start(appContext)
            .onSuccess {
                viewModelScope.launch {
                    container.settingsRepository.setOverlayEnabled(true)
                }
                emitMessage("Dynamic Island запущен в верхней части экрана")
            }
            .onFailure { error ->
                viewModelScope.launch {
                    container.settingsRepository.setOverlayEnabled(false)
                }
                emitMessage("Ошибка запуска острова: ${error.localizedMessage ?: "проверьте разрешения"}")
            }
    }

    fun openOverlayPermissionSettings() {
        PermissionHelper.openOverlaySettings(appContext).onFailure {
            emitMessage("Не удалось открыть настройки наложения окон")
        }
    }

    fun openNotificationListenerSettings() {
        PermissionHelper.openNotificationListenerSettings(appContext).onFailure {
            emitMessage("Не удалось открыть настройки доступа к уведомлениям")
        }
    }

    fun openDndPolicySettings() {
        PermissionHelper.openDndPolicySettings(appContext).onFailure {
            emitMessage("Не удалось открыть настройки «Не беспокоить»")
        }
    }

    fun openInternetPanel() {
        PermissionHelper.openInternetPanel(appContext).onFailure {
            emitMessage("Не удалось открыть панель сети")
        }
    }

    fun refreshInstalledApps() {
        viewModelScope.launch {
            container.installedAppsRepository.refreshInstalledApps()
        }
    }

    // --- Launcher 8-slot management ---
    fun togglePinApp(packageName: String) {
        val current = settings.value.pinnedPackages.toMutableList()
        if (packageName in current) {
            current.remove(packageName)
            savePinned(current)
            emitMessage("Приложение убрано из острова")
        } else {
            if (current.size >= SettingsRepository.MAX_PINNED_APPS) {
                emitMessage("Максимум 8 закреплённых приложений. Удалите одно для замены.")
                return
            }
            current.add(packageName)
            savePinned(current)
            emitMessage("Приложение закреплено в лаунчере")
        }
    }

    fun removePinnedApp(packageName: String) {
        val updated = settings.value.pinnedPackages.filterNot { it == packageName }
        savePinned(updated)
    }

    fun movePinnedApp(packageName: String, delta: Int) {
        val list = settings.value.pinnedPackages.toMutableList()
        val idx = list.indexOf(packageName)
        if (idx == -1) return
        val target = (idx + delta).coerceIn(0, list.lastIndex)
        if (target == idx) return
        val item = list.removeAt(idx)
        list.add(target, item)
        savePinned(list)
    }

    private fun savePinned(packages: List<String>) {
        viewModelScope.launch {
            container.settingsRepository.setPinnedPackages(packages)
        }
    }

    fun launchApp(packageName: String) {
        container.installedAppsRepository.launchApp(packageName).onFailure {
            emitMessage("Не удалось запустить приложение")
        }
    }

    fun launchSystemGameTurbo() {
        val pkg = container.installedAppsRepository.findSystemGameTurboPackage()
        if (pkg != null) {
            launchApp(pkg)
        } else {
            toggleGameTurbo(!settings.value.gameTurboActive)
        }
    }

    // --- Music ---
    fun musicPlayPause() {
        if (!container.mediaRepository.togglePlayPause()) {
            emitMessage("Нет активного медиаплеера")
        }
    }

    fun musicNext() {
        if (!container.mediaRepository.skipNext()) {
            emitMessage("Нет активного медиаплеера")
        }
    }

    fun musicPrev() {
        if (!container.mediaRepository.skipPrevious()) {
            emitMessage("Нет активного медиаплеера")
        }
    }

    fun musicSeek(positionMs: Long) {
        container.mediaRepository.seekTo(positionMs)
    }

    // --- System ---
    fun clearAppCache() {
        val freedKb = container.systemTelemetryRepository.clearAppCache()
        emitMessage("Кэш очищен: освобождено $freedKb КБ")
    }

    fun refreshSystemMetrics() {
        container.systemTelemetryRepository.refreshSystemMetrics()
    }

    // --- Gaming ---
    fun toggleGameTurbo(enabled: Boolean) {
        viewModelScope.launch {
            val res = container.gameTurboManager.setGameTurboEnabled(enabled, settings.value.gameTurboDnd)
            res.onSuccess { msg -> emitMessage(msg) }
        }
    }

    fun updateSettings(transform: (IslandSettings) -> IslandSettings) {
        viewModelScope.launch {
            container.settingsRepository.updateSettings(transform)
        }
    }

    fun resetSettingsDefaults() {
        viewModelScope.launch {
            container.settingsRepository.resetAppearanceAndLayoutDefaults()
            emitMessage("Настройки вида и положения сброшены")
        }
    }

    // --- Tools ---
    fun setTimerPreset(seconds: Int) = container.toolsManager.setTimerPreset(seconds)
    fun addTimerSeconds(delta: Int) = container.toolsManager.addTimerSeconds(delta)
    fun toggleTimer() = container.toolsManager.toggleTimer()
    fun resetTimer() = container.toolsManager.resetTimer()
    fun toggleStopwatch() = container.toolsManager.toggleStopwatch()
    fun recordStopwatchLap() = container.toolsManager.recordStopwatchLap()
    fun resetStopwatch() = container.toolsManager.resetStopwatch()
    fun onCalcKey(key: String) = container.toolsManager.onCalcKey(key)
    fun toggleFlashlight() = container.toolsManager.toggleFlashlight()

    fun buildPreviewCallbacks(): IslandCallbacks = IslandCallbacks(
        onToggleExpand = { togglePreviewExpanded() },
        onCollapse = { setPreviewExpanded(false) },
        onSelectSection = { section -> selectSection(section) },
        onLaunchApp = { pkg -> launchApp(pkg) },
        onOpenControlApp = { section ->
            selectSection(section)
            setPreviewExpanded(false)
        },
        onMusicPlayPause = { musicPlayPause() },
        onMusicNext = { musicNext() },
        onMusicPrev = { musicPrev() },
        onMusicSeek = { musicSeek(it) },
        onRequestNotificationListener = { openNotificationListenerSettings() },
        onClearAppCache = { clearAppCache() },
        onToggleGameTurbo = { toggleGameTurbo(it) },
        onToggleGameTurboDnd = { enabled -> updateSettings { it.copy(gameTurboDnd = enabled) } },
        onToggleGameTurboKeepScreen = { enabled -> updateSettings { it.copy(gameTurboKeepScreenOn = enabled) } },
        onToggleGameTurboHud = { enabled -> updateSettings { it.copy(gameTurboCompactHud = enabled) } },
        onOpenDndSettings = { openDndPolicySettings() },
        onOpenInternetPanel = { openInternetPanel() },
        onTimerPreset = { setTimerPreset(it) },
        onTimerAddSeconds = { addTimerSeconds(it) },
        onTimerToggle = { toggleTimer() },
        onTimerReset = { resetTimer() },
        onStopwatchToggle = { toggleStopwatch() },
        onStopwatchLap = { recordStopwatchLap() },
        onStopwatchReset = { resetStopwatch() },
        onCalcKey = { onCalcKey(it) },
        onToggleFlashlight = { toggleFlashlight() },
        onSelectAccent = { accent: IslandAccent -> updateSettings { it.copy(accent = accent) } },
        onSelectAnimStyle = { style: IslandAnimStyle -> updateSettings { it.copy(animStyle = style) } },
        onAdjustWidthDp = { delta ->
            updateSettings { it.copy(collapsedWidthDp = (it.collapsedWidthDp + delta).coerceIn(112, 260)) }
        },
        onAdjustTopOffsetDp = { delta ->
            updateSettings { it.copy(topOffsetDp = (it.topOffsetDp + delta).coerceIn(0, 96)) }
        },
        onStopOverlay = { toggleOverlayService(false) },
        onDismissBanner = { container.mediaRepository.dismissNotificationBanner() },
    )

    private fun emitMessage(text: String) {
        _snackbarMessage.tryEmit(text)
    }
}
