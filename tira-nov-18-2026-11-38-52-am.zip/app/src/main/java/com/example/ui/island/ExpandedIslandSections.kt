package com.example.ui.island

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.CleaningServices
import androidx.compose.material.icons.rounded.FlashlightOff
import androidx.compose.material.icons.rounded.FlashlightOn
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PowerSettingsNew
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material.icons.rounded.Thermostat
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.BatteryState
import com.example.data.model.InstalledAppInfo
import com.example.data.model.IslandAccent
import com.example.data.model.IslandAnimStyle
import com.example.data.model.IslandSection
import com.example.data.model.IslandSettings
import com.example.data.model.MusicState
import com.example.data.model.NetworkState
import com.example.data.model.SystemState
import com.example.data.model.ToolsState
import com.example.ui.theme.AmberThermal
import com.example.ui.theme.CoralAlert
import com.example.ui.theme.ElevatedSlate
import com.example.ui.theme.EmeraldMint
import com.example.ui.theme.HairlineBorder
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.ManropeFamily
import com.example.ui.theme.MidnightCard
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.util.formatDurationMs
import com.example.ui.util.formatSpeedBytesPerSec
import com.example.ui.util.formatStopwatchMs
import com.example.ui.util.formatTimerSeconds
import java.util.Locale

@Composable
fun IslandLauncherBody(
    pinnedApps: List<InstalledAppInfo>,
    accent: Color,
    callbacks: IslandCallbacks,
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (pinnedApps.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MidnightCard)
                    .padding(16.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = "Нет закреплённых приложений. Добавьте до 8 приложений в разделе Лаунчер.",
                    color = TextSecondary,
                    fontFamily = ManropeFamily,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                )
            }
        } else {
            val rows = pinnedApps.chunked(4)
            rows.forEach { rowApps ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    rowApps.forEach { app ->
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(MidnightCard)
                                .clickable { callbacks.onLaunchApp(app.packageName) }
                                .padding(vertical = 8.dp, horizontal = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(5.dp),
                        ) {
                            if (app.icon != null) {
                                Image(
                                    bitmap = app.icon,
                                    contentDescription = app.label,
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(RoundedCornerShape(10.dp)),
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(accent.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Apps,
                                        contentDescription = app.label,
                                        tint = accent,
                                        modifier = Modifier.size(18.dp),
                                    )
                                }
                            }
                            Text(
                                text = app.label,
                                color = TextPrimary,
                                fontFamily = ManropeFamily,
                                fontSize = 10.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                    repeat(4 - rowApps.size) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
        ) {
            FilledTonalButton(
                onClick = { callbacks.onOpenControlApp(IslandSection.LAUNCHER) },
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                colors = ButtonDefaults.filledTonalButtonColors(
                    containerColor = ElevatedSlate,
                    contentColor = accent,
                ),
            ) {
                Icon(Icons.Rounded.OpenInNew, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(6.dp))
                Text("Настроить 8 слотов", fontFamily = ManropeFamily, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun IslandMusicBody(
    music: MusicState,
    accent: Color,
    callbacks: IslandCallbacks,
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (!music.listenerConnected) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(MidnightCard)
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    text = "Нужен доступ к уведомлениям для управления плеером",
                    color = TextSecondary,
                    fontFamily = ManropeFamily,
                    fontSize = 11.sp,
                    modifier = Modifier.weight(1f).padding(end = 8.dp),
                )
                Button(
                    onClick = callbacks.onRequestNotificationListener,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color.Black),
                ) {
                    Text("Разрешить", fontFamily = ManropeFamily, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            val art = music.albumArt
            if (art != null) {
                Image(
                    bitmap = art.asImageBitmap(),
                    contentDescription = "Обложка трека",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape(14.dp)),
                )
            } else {
                Image(
                    painter = painterResource(id = R.drawable.img_default_album_art),
                    contentDescription = "Обложка трека",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape(14.dp)),
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = music.title,
                    color = TextPrimary,
                    fontFamily = ManropeFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = music.artist,
                    color = TextSecondary,
                    fontFamily = ManropeFamily,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (music.sourceAppName.isNotBlank()) {
                    Text(
                        text = music.sourceAppName,
                        color = accent,
                        fontFamily = ManropeFamily,
                        fontSize = 10.sp,
                        maxLines = 1,
                    )
                }
            }
        }

        val duration = music.durationMs.coerceAtLeast(1L)
        val progress = (music.positionMs.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
        Column {
            Slider(
                value = progress,
                onValueChange = { ratio ->
                    if (music.hasActiveSession && music.durationMs > 0L) {
                        callbacks.onMusicSeek((ratio * music.durationMs).toLong())
                    }
                },
                colors = SliderDefaults.colors(
                    thumbColor = accent,
                    activeTrackColor = accent,
                    inactiveTrackColor = ElevatedSlate,
                ),
                modifier = Modifier.height(24.dp),
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    text = formatDurationMs(music.positionMs),
                    color = TextMuted,
                    fontFamily = JetBrainsMonoFamily,
                    fontSize = 10.sp,
                )
                Text(
                    text = formatDurationMs(music.durationMs),
                    color = TextMuted,
                    fontFamily = JetBrainsMonoFamily,
                    fontSize = 10.sp,
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(
                onClick = callbacks.onMusicPrev,
                modifier = Modifier.size(48.dp),
            ) {
                Icon(Icons.Rounded.SkipPrevious, contentDescription = "Предыдущий трек", tint = TextPrimary)
            }
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(accent)
                    .clickable(onClick = callbacks.onMusicPlayPause),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = if (music.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = if (music.isPlaying) "Пауза" else "Воспроизвести",
                    tint = Color.Black,
                    modifier = Modifier.size(26.dp),
                )
            }
            IconButton(
                onClick = callbacks.onMusicNext,
                modifier = Modifier.size(48.dp),
            ) {
                Icon(Icons.Rounded.SkipNext, contentDescription = "Следующий трек", tint = TextPrimary)
            }
        }
    }
}

@Composable
fun IslandBatteryBody(
    battery: BatteryState,
    accent: Color,
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(MidnightCard)
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background((if (battery.isCharging) EmeraldMint else accent).copy(alpha = 0.16f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = Icons.Rounded.BatteryChargingFull,
                        contentDescription = "Заряд батареи",
                        tint = if (battery.isCharging) EmeraldMint else accent,
                    )
                }
                Column {
                    Text(
                        text = "${battery.levelPercent}%",
                        color = TextPrimary,
                        fontFamily = JetBrainsMonoFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp,
                    )
                    Text(
                        text = "${battery.statusRu} · ${battery.chargeSourceRu}",
                        color = if (battery.isCharging) EmeraldMint else TextSecondary,
                        fontFamily = ManropeFamily,
                        fontSize = 11.sp,
                    )
                }
            }
            Text(
                text = battery.technology,
                color = TextMuted,
                fontFamily = JetBrainsMonoFamily,
                fontSize = 11.sp,
            )
        }

        LinearProgressIndicator(
            progress = { battery.levelPercent / 100f },
            color = if (battery.isCharging) EmeraldMint else accent,
            trackColor = ElevatedSlate,
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp)),
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            IslandStatChip("Напряжение", String.format(Locale.US, "%.2f В", battery.voltageV), Modifier.weight(1f))
            IslandStatChip("Ток", "${battery.currentMa} мА", Modifier.weight(1f))
            IslandStatChip("Состояние", battery.healthRu, Modifier.weight(1f))
        }
    }
}

@Composable
fun IslandSystemBody(
    system: SystemState,
    accent: Color,
    callbacks: IslandCallbacks,
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            val tempColor = when {
                system.batteryTempC >= 43f -> CoralAlert
                system.batteryTempC >= 37f -> AmberThermal
                else -> EmeraldMint
            }
            Row(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(14.dp))
                    .background(MidnightCard)
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Icon(Icons.Rounded.Thermostat, contentDescription = null, tint = tempColor, modifier = Modifier.size(20.dp))
                Column {
                    Text(
                        text = String.format(Locale.US, "%.1f °C", system.batteryTempC),
                        color = TextPrimary,
                        fontFamily = JetBrainsMonoFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                    )
                    Text(
                        text = "Темп: ${system.thermalStatusRu}",
                        color = tempColor,
                        fontFamily = ManropeFamily,
                        fontSize = 10.sp,
                    )
                }
            }

            Column(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(14.dp))
                    .background(MidnightCard)
                    .padding(10.dp),
            ) {
                Text(
                    text = "${system.availableRamMb} МБ",
                    color = TextPrimary,
                    fontFamily = JetBrainsMonoFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                )
                Text(
                    text = "Свободно ОЗУ (${100 - system.ramUsagePercent}%)",
                    color = TextSecondary,
                    fontFamily = ManropeFamily,
                    fontSize = 10.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(MidnightCard)
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Память ОЗУ", color = TextSecondary, fontFamily = ManropeFamily, fontSize = 11.sp)
                Text(
                    "${system.totalRamMb - system.availableRamMb} / ${system.totalRamMb} МБ",
                    color = TextPrimary,
                    fontFamily = JetBrainsMonoFamily,
                    fontSize = 11.sp,
                )
            }
            LinearProgressIndicator(
                progress = { system.ramUsagePercent / 100f },
                color = accent,
                trackColor = ElevatedSlate,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
            )
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(
                    "Накопитель: свободно ${String.format(Locale.US, "%.1f", system.availableStorageGb)} ГБ",
                    color = TextMuted,
                    fontFamily = ManropeFamily,
                    fontSize = 10.sp,
                )
                Text(
                    "${system.cpuCores} ядер · ${system.uptimeFormatted}",
                    color = TextMuted,
                    fontFamily = JetBrainsMonoFamily,
                    fontSize = 10.sp,
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "Кэш Tira: ${system.appCacheKb} КБ",
                color = TextMuted,
                fontFamily = JetBrainsMonoFamily,
                fontSize = 11.sp,
            )
            FilledTonalButton(
                onClick = callbacks.onClearAppCache,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                colors = ButtonDefaults.filledTonalButtonColors(containerColor = ElevatedSlate, contentColor = accent),
            ) {
                Icon(Icons.Rounded.CleaningServices, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(6.dp))
                Text("Очистить кэш", fontFamily = ManropeFamily, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun IslandGamingBody(
    settings: IslandSettings,
    system: SystemState,
    games: List<InstalledAppInfo>,
    accent: Color,
    callbacks: IslandCallbacks,
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(MidnightCard)
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Icon(
                    imageVector = Icons.Rounded.SportsEsports,
                    contentDescription = "Game Turbo",
                    tint = if (settings.gameTurboActive) EmeraldMint else TextSecondary,
                )
                Column {
                    Text(
                        text = "Game Turbo",
                        color = TextPrimary,
                        fontFamily = ManropeFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                    )
                    Text(
                        text = if (settings.gameTurboActive) "Активен · HUD включён" else "Готов к запуску",
                        color = if (settings.gameTurboActive) EmeraldMint else TextSecondary,
                        fontFamily = ManropeFamily,
                        fontSize = 11.sp,
                    )
                }
            }
            Switch(
                checked = settings.gameTurboActive,
                onCheckedChange = callbacks.onToggleGameTurbo,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.Black,
                    checkedTrackColor = EmeraldMint,
                ),
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            IslandStatChip("Нагрев", "${String.format(Locale.US, "%.1f", system.batteryTempC)}°C", Modifier.weight(1f))
            IslandStatChip("ОЗУ своб.", "${system.availableRamMb} МБ", Modifier.weight(1f))
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            MiniTogglePill("Не беспокоить", settings.gameTurboDnd, accent, Modifier.weight(1f)) {
                callbacks.onToggleGameTurboDnd(!settings.gameTurboDnd)
            }
            MiniTogglePill("Экран активен", settings.gameTurboKeepScreenOn, accent, Modifier.weight(1f)) {
                callbacks.onToggleGameTurboKeepScreen(!settings.gameTurboKeepScreenOn)
            }
        }

        if (games.isNotEmpty()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                games.take(4).forEach { game ->
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(MidnightCard)
                            .clickable { callbacks.onLaunchApp(game.packageName) }
                            .padding(6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        if (game.icon != null) {
                            Image(
                                bitmap = game.icon,
                                contentDescription = game.label,
                                modifier = Modifier.size(28.dp).clip(RoundedCornerShape(8.dp)),
                            )
                        }
                        Text(
                            text = game.label,
                            color = TextPrimary,
                            fontFamily = ManropeFamily,
                            fontSize = 10.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
        } else {
            FilledTonalButton(
                onClick = { callbacks.onOpenControlApp(IslandSection.GAMING) },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.filledTonalButtonColors(containerColor = ElevatedSlate, contentColor = accent),
            ) {
                Text("Открыть игровой хаб", fontFamily = ManropeFamily, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun IslandNetworkBody(
    network: NetworkState,
    accent: Color,
    callbacks: IslandCallbacks,
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(MidnightCard)
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Icon(
                    imageVector = Icons.Rounded.Wifi,
                    contentDescription = "Сеть",
                    tint = if (network.isConnected) accent else CoralAlert,
                )
                Column {
                    Text(
                        text = network.networkName,
                        color = TextPrimary,
                        fontFamily = ManropeFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = if (network.linkSpeedMbps > 0) {
                            "${network.transportTypeRu} · ${network.linkSpeedMbps} Мбит/с"
                        } else {
                            network.transportTypeRu
                        },
                        color = TextSecondary,
                        fontFamily = ManropeFamily,
                        fontSize = 11.sp,
                    )
                }
            }
            FilledTonalButton(
                onClick = callbacks.onOpenInternetPanel,
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                colors = ButtonDefaults.filledTonalButtonColors(containerColor = ElevatedSlate, contentColor = accent),
            ) {
                Text("Сеть", fontFamily = ManropeFamily, fontSize = 11.sp)
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MidnightCard)
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Icon(Icons.Rounded.ArrowDownward, contentDescription = null, tint = EmeraldMint, modifier = Modifier.size(16.dp))
                Column {
                    Text("Входящая", color = TextMuted, fontFamily = ManropeFamily, fontSize = 10.sp)
                    Text(
                        formatSpeedBytesPerSec(network.rxBytesPerSec),
                        color = TextPrimary,
                        fontFamily = JetBrainsMonoFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                    )
                }
            }
            Row(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MidnightCard)
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Icon(Icons.Rounded.ArrowUpward, contentDescription = null, tint = accent, modifier = Modifier.size(16.dp))
                Column {
                    Text("Исходящая", color = TextMuted, fontFamily = ManropeFamily, fontSize = 10.sp)
                    Text(
                        formatSpeedBytesPerSec(network.txBytesPerSec),
                        color = TextPrimary,
                        fontFamily = JetBrainsMonoFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                    )
                }
            }
        }

        SpeedSparkline(
            samples = network.speedHistoryRxKbps,
            lineColor = accent,
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(MidnightCard)
                .padding(6.dp),
        )
    }
}

@Composable
fun SpeedSparkline(
    samples: List<Float>,
    lineColor: Color,
    modifier: Modifier = Modifier,
) {
    Canvas(modifier = modifier) {
        if (samples.size < 2) return@Canvas
        val maxVal = (samples.maxOrNull() ?: 1f).coerceAtLeast(10f)
        val stepX = size.width / (samples.size - 1).coerceAtLeast(1)
        val path = Path()
        samples.forEachIndexed { index, value ->
            val x = index * stepX
            val y = size.height - ((value / maxVal).coerceIn(0f, 1f) * (size.height - 6f)) - 3f
            if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(
            path = path,
            color = lineColor,
            style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round),
        )
    }
}

@Composable
fun IslandToolsBody(
    tools: ToolsState,
    accent: Color,
    callbacks: IslandCallbacks,
) {
    var activeTool by remember { mutableIntStateOf(0) } // 0=Таймер, 1=Секундомер, 2=Калькулятор, 3=Фонарик
    val labels = listOf("Таймер", "Секунд.", "Кальк.", "Фонарь")

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            labels.forEachIndexed { index, title ->
                val selected = activeTool == index
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (selected) accent else MidnightCard)
                        .clickable { activeTool = index }
                        .padding(vertical = 7.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = title,
                        color = if (selected) Color.Black else TextSecondary,
                        fontFamily = ManropeFamily,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                        fontSize = 11.sp,
                    )
                }
            }
        }

        when (activeTool) {
            0 -> {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(MidnightCard)
                        .padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(
                        text = formatTimerSeconds(tools.timer.remainingSeconds),
                        color = if (tools.timer.isFinished) AmberThermal else TextPrimary,
                        fontFamily = JetBrainsMonoFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 26.sp,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(60 to "1м", 180 to "3м", 300 to "5м", 600 to "10м").forEach { (sec, label) ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(ElevatedSlate)
                                    .clickable { callbacks.onTimerPreset(sec) }
                                    .padding(horizontal = 10.dp, vertical = 5.dp),
                            ) {
                                Text(label, color = TextPrimary, fontFamily = JetBrainsMonoFamily, fontSize = 11.sp)
                            }
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Button(
                            onClick = callbacks.onTimerToggle,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color.Black),
                        ) {
                            Text(
                                if (tools.timer.isRunning) "Пауза" else "Старт",
                                fontFamily = ManropeFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                            )
                        }
                        FilledTonalButton(
                            onClick = callbacks.onTimerReset,
                            colors = ButtonDefaults.filledTonalButtonColors(containerColor = ElevatedSlate, contentColor = TextPrimary),
                        ) {
                            Icon(Icons.Rounded.Refresh, contentDescription = "Сброс", modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }

            1 -> {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(MidnightCard)
                        .padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(
                        text = formatStopwatchMs(tools.stopwatch.elapsedMs),
                        color = TextPrimary,
                        fontFamily = JetBrainsMonoFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 24.sp,
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Button(
                            onClick = callbacks.onStopwatchToggle,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color.Black),
                        ) {
                            Text(
                                if (tools.stopwatch.isRunning) "Стоп" else "Старт",
                                fontFamily = ManropeFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                            )
                        }
                        FilledTonalButton(
                            onClick = callbacks.onStopwatchLap,
                            colors = ButtonDefaults.filledTonalButtonColors(containerColor = ElevatedSlate, contentColor = TextPrimary),
                        ) {
                            Text("Круг", fontFamily = ManropeFamily, fontSize = 12.sp)
                        }
                        FilledTonalButton(
                            onClick = callbacks.onStopwatchReset,
                            colors = ButtonDefaults.filledTonalButtonColors(containerColor = ElevatedSlate, contentColor = TextPrimary),
                        ) {
                            Icon(Icons.Rounded.Refresh, contentDescription = "Сброс", modifier = Modifier.size(16.dp))
                        }
                    }
                    if (tools.stopwatch.lapsMs.isNotEmpty()) {
                        Text(
                            text = "Круг: ${formatStopwatchMs(tools.stopwatch.lapsMs.first())}",
                            color = TextSecondary,
                            fontFamily = JetBrainsMonoFamily,
                            fontSize = 11.sp,
                        )
                    }
                }
            }

            2 -> {
                CompactCalculatorGrid(
                    display = tools.calculator.display,
                    error = tools.calculator.error,
                    accent = accent,
                    onKey = callbacks.onCalcKey,
                )
            }

            3 -> {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(MidnightCard)
                        .padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    val torchOn = tools.flashlight.isOn
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(if (torchOn) Color.White else ElevatedSlate)
                            .clickable(onClick = callbacks.onToggleFlashlight),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            imageVector = if (torchOn) Icons.Rounded.FlashlightOn else Icons.Rounded.FlashlightOff,
                            contentDescription = "Фонарик",
                            tint = if (torchOn) Color.Black else TextPrimary,
                            modifier = Modifier.size(30.dp),
                        )
                    }
                    Text(
                        text = when {
                            tools.flashlight.errorMessage != null -> tools.flashlight.errorMessage
                            torchOn -> "Фонарик включён"
                            else -> "Нажмите для включения вспышки"
                        },
                        color = if (tools.flashlight.errorMessage != null) CoralAlert else TextSecondary,
                        fontFamily = ManropeFamily,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                    )
                }
            }
        }
    }
}

@Composable
fun CompactCalculatorGrid(
    display: String,
    error: String?,
    accent: Color,
    onKey: (String) -> Unit,
) {
    val rows = listOf(
        listOf("C", "⌫", "%", "÷"),
        listOf("7", "8", "9", "×"),
        listOf("4", "5", "6", "-"),
        listOf("1", "2", "3", "+"),
        listOf("+/-", "0", ".", "="),
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(MidnightCard)
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text(
            text = error ?: display,
            color = if (error != null) CoralAlert else TextPrimary,
            fontFamily = JetBrainsMonoFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 20.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.End,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp),
        )
        rows.forEach { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                row.forEach { key ->
                    val isEq = key == "="
                    val isOp = key in setOf("÷", "×", "-", "+", "%", "C", "⌫")
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(34.dp)
                            .clip(RoundedCornerShape(9.dp))
                            .background(
                                when {
                                    isEq -> accent
                                    isOp -> ElevatedSlate
                                    else -> Color(0xFF222736)
                                }
                            )
                            .clickable { onKey(key) },
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            text = key,
                            color = if (isEq) Color.Black else if (isOp) accent else TextPrimary,
                            fontFamily = JetBrainsMonoFamily,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp,
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun IslandSettingsBody(
    settings: IslandSettings,
    accent: Color,
    callbacks: IslandCallbacks,
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("Акцент", color = TextSecondary, fontFamily = ManropeFamily, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IslandAccent.entries.forEach { item ->
                    val selected = item == settings.accent
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(item.primaryColor)
                            .then(
                                if (selected) Modifier.border(2.dp, Color.White, CircleShape) else Modifier
                            )
                            .clickable { callbacks.onSelectAccent(item) },
                    )
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            IslandAnimStyle.entries.forEach { style ->
                val selected = style == settings.animStyle
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (selected) accent else MidnightCard)
                        .clickable { callbacks.onSelectAnimStyle(style) }
                        .padding(vertical = 7.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = style.titleRu,
                        color = if (selected) Color.Black else TextSecondary,
                        fontFamily = ManropeFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 11.sp,
                    )
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            StepperChip(
                label = "Ширина: ${settings.collapsedWidthDp}dp",
                onMinus = { callbacks.onAdjustWidthDp(-12) },
                onPlus = { callbacks.onAdjustWidthDp(12) },
                modifier = Modifier.weight(1f),
            )
            StepperChip(
                label = "Отступ: ${settings.topOffsetDp}dp",
                onMinus = { callbacks.onAdjustTopOffsetDp(-4) },
                onPlus = { callbacks.onAdjustTopOffsetDp(4) },
                modifier = Modifier.weight(1f),
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            FilledTonalButton(
                onClick = { callbacks.onOpenControlApp(IslandSection.SETTINGS) },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.filledTonalButtonColors(containerColor = ElevatedSlate, contentColor = accent),
            ) {
                Text("Все настройки", fontFamily = ManropeFamily, fontSize = 11.sp)
            }
            if (settings.isOverlayEnabled) {
                FilledTonalButton(
                    onClick = callbacks.onStopOverlay,
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = CoralAlert.copy(alpha = 0.18f),
                        contentColor = CoralAlert,
                    ),
                ) {
                    Icon(Icons.Rounded.PowerSettingsNew, contentDescription = "Выключить", modifier = Modifier.size(15.dp))
                }
            }
        }
    }
}

@Composable
private fun StepperChip(
    label: String,
    onMinus: () -> Unit,
    onPlus: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(MidnightCard)
            .padding(horizontal = 6.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        IconButton(onClick = onMinus, modifier = Modifier.size(28.dp)) {
            Icon(Icons.Rounded.Remove, contentDescription = "Уменьшить", tint = TextSecondary, modifier = Modifier.size(16.dp))
        }
        Text(
            text = label,
            color = TextPrimary,
            fontFamily = JetBrainsMonoFamily,
            fontSize = 10.sp,
            maxLines = 1,
        )
        IconButton(onClick = onPlus, modifier = Modifier.size(28.dp)) {
            Icon(Icons.Rounded.Add, contentDescription = "Увеличить", tint = TextSecondary, modifier = Modifier.size(16.dp))
        }
    }
}

@Composable
private fun IslandStatChip(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(MidnightCard)
            .padding(horizontal = 10.dp, vertical = 8.dp),
    ) {
        Text(label, color = TextMuted, fontFamily = ManropeFamily, fontSize = 10.sp, maxLines = 1)
        Text(
            value,
            color = TextPrimary,
            fontFamily = JetBrainsMonoFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            maxLines = 1,
        )
    }
}

@Composable
private fun MiniTogglePill(
    label: String,
    active: Boolean,
    accent: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (active) accent.copy(alpha = 0.2f) else MidnightCard)
            .border(
                width = 1.dp,
                color = if (active) accent else HairlineBorder,
                shape = RoundedCornerShape(10.dp),
            )
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp, horizontal = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = if (active) accent else TextSecondary,
            fontFamily = ManropeFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}
