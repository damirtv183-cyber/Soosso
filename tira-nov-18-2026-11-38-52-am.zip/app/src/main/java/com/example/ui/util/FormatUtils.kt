package com.example.ui.util

import java.util.Locale

fun formatDurationMs(ms: Long): String {
    val totalSec = (ms.coerceAtLeast(0L)) / 1000L
    val mins = totalSec / 60L
    val secs = totalSec % 60L
    return String.format(Locale.US, "%d:%02d", mins, secs)
}

fun formatTimerSeconds(totalSeconds: Int): String {
    val safe = totalSeconds.coerceAtLeast(0)
    val hrs = safe / 3600
    val mins = (safe % 3600) / 60
    val secs = safe % 60
    return if (hrs > 0) {
        String.format(Locale.US, "%d:%02d:%02d", hrs, mins, secs)
    } else {
        String.format(Locale.US, "%02d:%02d", mins, secs)
    }
}

fun formatStopwatchMs(ms: Long): String {
    val safe = ms.coerceAtLeast(0L)
    val mins = (safe / 60000L)
    val secs = (safe % 60000L) / 1000L
    val centis = (safe % 1000L) / 10L
    return String.format(Locale.US, "%02d:%02d.%02d", mins, secs, centis)
}

fun formatSpeedBytesPerSec(bytesPerSec: Long): String {
    val b = bytesPerSec.coerceAtLeast(0L)
    return when {
        b < 1024L -> "$b Б/с"
        b < 1024L * 1024L -> String.format(Locale.US, "%.1f КБ/с", b / 1024f)
        else -> String.format(Locale.US, "%.2f МБ/с", b / (1024f * 1024f))
    }
}
