package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Pure Monochrome Black & White luxury palette for Tira — Dynamic Island Pro
val ObsidianVoid = Color(0xFF050507)
val ObsidianIsland = Color(0xFF000000)
val SmokedSurface = Color(0xFF0E0F13)
val MidnightCard = Color(0xFF15161B)
val ElevatedSlate = Color(0xFF20222A)
val HairlineBorder = Color(0xFF2B2E38)

val TextPrimary = Color(0xFFF8F9FA)
val TextSecondary = Color(0xFFA0A6B2)
val TextMuted = Color(0xFF69707D)

// Monochrome finishes & restrained semantic accents
val PureWhite = Color(0xFFFFFFFF)
val PlatinumSilver = Color(0xFFD5DAE3)
val TitaniumGrey = Color(0xFFAAB2C0)
val FrostWhite = Color(0xFFEEF2F6)
val WarmIvory = Color(0xFFEAE4DA)

// Subtle semantic indicators (restrained, never garish neon)
val EmeraldMint = Color(0xFFE4E8EE)
val AmberThermal = Color(0xFFD6B98C)
val CoralAlert = Color(0xFFE07A7A)
