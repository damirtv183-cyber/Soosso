package com.example.ui.island

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BatteryState
import com.example.data.model.InstalledAppInfo
import com.example.data.model.IslandSection
import com.example.data.model.IslandSettings
import com.example.data.model.MusicState
import com.example.data.model.NetworkState
import com.example.data.model.NotificationBanner
import com.example.data.model.SystemState
import com.example.data.model.ToolsState
import com.example.ui.theme.HairlineBorder
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.ManropeFamily
import com.example.ui.theme.MidnightCard
import com.example.ui.theme.ObsidianIsland
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun DynamicIslandHost(
    isExpanded: Boolean,
    activeSection: IslandSection,
    settings: IslandSettings,
    pinnedApps: List<InstalledAppInfo>,
    detectedGames: List<InstalledAppInfo>,
    music: MusicState,
    battery: BatteryState,
    system: SystemState,
    network: NetworkState,
    tools: ToolsState,
    banner: NotificationBanner?,
    callbacks: IslandCallbacks,
    modifier: Modifier = Modifier,
) {
    val accent = settings.accent.primaryColor
    val secondaryAccent = settings.accent.secondaryColor

    val stiffness = settings.animStyle.stiffness * settings.animSpeedMultiplier
    val damping = settings.animStyle.dampingRatio.coerceAtLeast(0.88f)

    val targetWidth = if (isExpanded) settings.expandedWidthDp.dp else settings.collapsedWidthDp.dp
    val targetCorner = if (isExpanded) 28.dp else settings.cornerRadiusDp.dp

    val animatedWidth by animateDpAsState(
        targetValue = targetWidth,
        animationSpec = spring(dampingRatio = damping, stiffness = stiffness),
        label = "island_width",
    )
    val animatedCorner by animateDpAsState(
        targetValue = targetCorner,
        animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = stiffness),
        label = "island_corner",
    )

    val borderBrush = remember(settings.glowBorderEnabled, accent, secondaryAccent, isExpanded) {
        if (settings.glowBorderEnabled) {
            Brush.verticalGradient(
                colors = listOf(
                    accent.copy(alpha = if (isExpanded) 0.48f else 0.42f),
                    secondaryAccent.copy(alpha = 0.18f),
                    HairlineBorder.copy(alpha = 0.7f),
                ),
            )
        } else {
            Brush.verticalGradient(listOf(HairlineBorder, HairlineBorder))
        }
    }

    val shape = RoundedCornerShape(animatedCorner)

    Box(
        modifier = modifier.padding(horizontal = 4.dp),
        contentAlignment = Alignment.TopCenter,
    ) {
        Surface(
            color = ObsidianIsland.copy(alpha = settings.capsuleOpacity),
            shape = shape,
            shadowElevation = if (isExpanded) 18.dp else 8.dp,
            modifier = Modifier
                .width(animatedWidth)
                .shadow(
                    elevation = if (isExpanded) 16.dp else 6.dp,
                    shape = shape,
                    ambientColor = Color.White.copy(alpha = 0.12f),
                    spotColor = Color.White.copy(alpha = 0.14f),
                )
                .border(width = 1.dp, brush = borderBrush, shape = shape)
                .clip(shape)
                .testTag("dynamic_island_capsule"),
        ) {
            if (!isExpanded) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(settings.collapsedHeightDp.dp)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = callbacks.onToggleExpand,
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    CollapsedCapsuleContent(
                        settings = settings,
                        music = music,
                        battery = battery,
                        system = system,
                        tools = tools,
                        banner = banner,
                    )
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    // Header bar (tap to collapse)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .clickable(onClick = callbacks.onCollapse)
                            .padding(horizontal = 4.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(accent),
                            )
                            Text(
                                text = "Tira · ${activeSection.titleRu}",
                                color = TextPrimary,
                                fontFamily = ManropeFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            Text(
                                text = "${battery.levelPercent}%",
                                color = TextSecondary,
                                fontFamily = JetBrainsMonoFamily,
                                fontSize = 11.sp,
                            )
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(MidnightCard),
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.KeyboardArrowUp,
                                    contentDescription = "Свернуть остров",
                                    tint = TextPrimary,
                                    modifier = Modifier.size(18.dp),
                                )
                            }
                        }
                    }

                    // 8-section monochrome pill navigation strip
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        IslandSection.entries.forEach { section ->
                            val selected = section == activeSection
                            val bg by animateColorAsState(
                                targetValue = if (selected) accent else MidnightCard,
                                animationSpec = tween(160),
                                label = "pill_bg_${section.name}",
                            )
                            val fg by animateColorAsState(
                                targetValue = if (selected) Color.Black else TextSecondary,
                                animationSpec = tween(160),
                                label = "pill_fg_${section.name}",
                            )
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(bg)
                                    .clickable { callbacks.onSelectSection(section) }
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp),
                            ) {
                                Icon(
                                    imageVector = section.icon,
                                    contentDescription = section.titleRu,
                                    tint = fg,
                                    modifier = Modifier.size(14.dp),
                                )
                                Text(
                                    text = section.shortTitleRu,
                                    color = fg,
                                    fontFamily = ManropeFamily,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 11.sp,
                                )
                            }
                        }
                    }

                    // Clean crossfade transition between sections without layout jitter
                    val durationIn = (180 / settings.animSpeedMultiplier).toInt().coerceIn(80, 320)
                    val durationOut = (120 / settings.animSpeedMultiplier).toInt().coerceIn(60, 220)

                    AnimatedContent(
                        targetState = activeSection,
                        transitionSpec = {
                            fadeIn(tween(durationIn)) togetherWith fadeOut(tween(durationOut))
                        },
                        label = "expanded_island_section",
                    ) { section ->
                        when (section) {
                            IslandSection.LAUNCHER -> IslandLauncherBody(
                                pinnedApps = pinnedApps,
                                accent = accent,
                                callbacks = callbacks,
                            )
                            IslandSection.MUSIC -> IslandMusicBody(
                                music = music,
                                accent = accent,
                                callbacks = callbacks,
                            )
                            IslandSection.BATTERY -> IslandBatteryBody(
                                battery = battery,
                                accent = accent,
                            )
                            IslandSection.SYSTEM -> IslandSystemBody(
                                system = system,
                                accent = accent,
                                callbacks = callbacks,
                            )
                            IslandSection.GAMING -> IslandGamingBody(
                                settings = settings,
                                system = system,
                                games = detectedGames,
                                accent = accent,
                                callbacks = callbacks,
                            )
                            IslandSection.NETWORK -> IslandNetworkBody(
                                network = network,
                                accent = accent,
                                callbacks = callbacks,
                            )
                            IslandSection.TOOLS -> IslandToolsBody(
                                tools = tools,
                                accent = accent,
                                callbacks = callbacks,
                            )
                            IslandSection.SETTINGS -> IslandSettingsBody(
                                settings = settings,
                                accent = accent,
                                callbacks = callbacks,
                            )
                        }
                    }
                }
            }
        }
    }
}
