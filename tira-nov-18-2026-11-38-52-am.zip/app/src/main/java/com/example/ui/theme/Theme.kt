package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.data.model.IslandAccent

val TiraShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(36.dp),
)

@Composable
fun TiraTheme(
    accent: IslandAccent = IslandAccent.PURE_WHITE,
    content: @Composable () -> Unit,
) {
    val primaryAccent = accent.primaryColor
    val secondaryAccent = accent.secondaryColor

    val colorScheme = darkColorScheme(
        primary = primaryAccent,
        onPrimary = ObsidianIsland,
        primaryContainer = primaryAccent.copy(alpha = 0.14f),
        onPrimaryContainer = primaryAccent,
        secondary = secondaryAccent,
        onSecondary = ObsidianIsland,
        secondaryContainer = secondaryAccent.copy(alpha = 0.14f),
        onSecondaryContainer = secondaryAccent,
        tertiary = PlatinumSilver,
        onTertiary = ObsidianIsland,
        background = ObsidianVoid,
        onBackground = TextPrimary,
        surface = SmokedSurface,
        onSurface = TextPrimary,
        surfaceVariant = MidnightCard,
        onSurfaceVariant = TextSecondary,
        surfaceContainerLowest = ObsidianIsland,
        surfaceContainerLow = SmokedSurface,
        surfaceContainer = MidnightCard,
        surfaceContainerHigh = ElevatedSlate,
        outline = HairlineBorder,
        outlineVariant = HairlineBorder.copy(alpha = 0.6f),
        error = CoralAlert,
        onError = Color.Black,
    )

    MaterialTheme(
        colorScheme = colorScheme,
        typography = TiraTypography,
        shapes = TiraShapes,
        content = content,
    )
}
