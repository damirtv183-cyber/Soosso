package com.example.ui.island

import androidx.compose.runtime.Immutable
import com.example.data.model.IslandAccent
import com.example.data.model.IslandAnimStyle
import com.example.data.model.IslandSection

@Immutable
data class IslandCallbacks(
    val onToggleExpand: () -> Unit = {},
    val onCollapse: () -> Unit = {},
    val onSelectSection: (IslandSection) -> Unit = {},
    val onLaunchApp: (String) -> Unit = {},
    val onOpenControlApp: (IslandSection) -> Unit = {},
    val onMusicPlayPause: () -> Unit = {},
    val onMusicNext: () -> Unit = {},
    val onMusicPrev: () -> Unit = {},
    val onMusicSeek: (Long) -> Unit = {},
    val onRequestNotificationListener: () -> Unit = {},
    val onClearAppCache: () -> Unit = {},
    val onToggleGameTurbo: (Boolean) -> Unit = {},
    val onToggleGameTurboDnd: (Boolean) -> Unit = {},
    val onToggleGameTurboKeepScreen: (Boolean) -> Unit = {},
    val onToggleGameTurboHud: (Boolean) -> Unit = {},
    val onOpenDndSettings: () -> Unit = {},
    val onOpenInternetPanel: () -> Unit = {},
    val onTimerPreset: (Int) -> Unit = {},
    val onTimerAddSeconds: (Int) -> Unit = {},
    val onTimerToggle: () -> Unit = {},
    val onTimerReset: () -> Unit = {},
    val onStopwatchToggle: () -> Unit = {},
    val onStopwatchLap: () -> Unit = {},
    val onStopwatchReset: () -> Unit = {},
    val onCalcKey: (String) -> Unit = {},
    val onToggleFlashlight: () -> Unit = {},
    val onSelectAccent: (IslandAccent) -> Unit = {},
    val onSelectAnimStyle: (IslandAnimStyle) -> Unit = {},
    val onAdjustWidthDp: (Int) -> Unit = {},
    val onAdjustTopOffsetDp: (Int) -> Unit = {},
    val onStopOverlay: () -> Unit = {},
    val onDismissBanner: () -> Unit = {},
)
