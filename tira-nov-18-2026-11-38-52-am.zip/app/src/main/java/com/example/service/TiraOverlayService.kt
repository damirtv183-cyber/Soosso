package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.Toast
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.MainActivity
import com.example.R
import com.example.TiraApplication
import com.example.data.model.IslandSection
import com.example.data.model.IslandSettings
import com.example.data.repository.PermissionHelper
import com.example.ui.island.DynamicIslandHost
import com.example.ui.island.IslandCallbacks
import com.example.ui.theme.TiraTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class TiraOverlayService :
    Service(),
    LifecycleOwner,
    ViewModelStoreOwner,
    SavedStateRegistryOwner {

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val store = ViewModelStore()
    private val savedStateRegistryController = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry
        get() = savedStateRegistryController.savedStateRegistry

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private lateinit var windowManager: WindowManager
    private var rootContainer: FrameLayout? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    private val isExpandedFlow = MutableStateFlow(false)
    private val activeSectionFlow = MutableStateFlow(IslandSection.LAUNCHER)
    private val screenWidthDpFlow = MutableStateFlow(360)
    private var autoCollapseJob: Job? = null
    private var currentSettingsSnapshot = IslandSettings()

    override fun onCreate() {
        super.onCreate()
        _lastError.value = null
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        updateScreenDimensions()

        createNotificationChannel()
        val notification = buildForegroundNotification()
        val fgResult = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE,
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        }
        if (fgResult.isFailure) {
            val err = fgResult.exceptionOrNull()?.localizedMessage ?: "Ошибка запуска Foreground Service"
            Log.e(TAG, "startForeground failed", fgResult.exceptionOrNull())
            _lastError.value = err
            stopSelf()
            return
        }

        if (!Settings.canDrawOverlays(this)) {
            _lastError.value = getString(R.string.error_overlay_permission)
            Toast.makeText(this, getString(R.string.error_overlay_permission), Toast.LENGTH_LONG).show()
            serviceScope.launch {
                (application as? TiraApplication)?.container?.settingsRepository?.setOverlayEnabled(false)
                stopSelf()
            }
            return
        }

        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

        attachOverlayView()
        observeSettingsForLayout()
        _isRunning.value = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_OVERLAY) {
            serviceScope.launch {
                (application as? TiraApplication)?.container?.settingsRepository?.setOverlayEnabled(false)
                stopSelf()
            }
            return START_NOT_STICKY
        }
        if (rootContainer == null && Settings.canDrawOverlays(this)) {
            attachOverlayView()
        }
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        updateScreenDimensions()
        updateWindowParamsForSettings(currentSettingsSnapshot)
    }

    private fun updateScreenDimensions() {
        val metrics = resources.displayMetrics
        val dp = (metrics.widthPixels / metrics.density).roundToInt().coerceAtLeast(300)
        screenWidthDpFlow.value = dp
    }

    private fun attachOverlayView() {
        if (rootContainer != null) return
        val app = application as? TiraApplication ?: return
        val container = app.container

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            x = 0
            y = dpToPx(currentSettingsSnapshot.topOffsetDp)
            layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        layoutParams = params

        val wrapper = object : FrameLayout(this) {
            override fun onTouchEvent(event: MotionEvent?): Boolean {
                if (event?.action == MotionEvent.ACTION_OUTSIDE && isExpandedFlow.value) {
                    collapseIsland()
                    return true
                }
                return super.onTouchEvent(event)
            }
        }.apply {
            setViewTreeLifecycleOwner(this@TiraOverlayService)
            setViewTreeViewModelStoreOwner(this@TiraOverlayService)
            setViewTreeSavedStateRegistryOwner(this@TiraOverlayService)
        }

        val composeView = ComposeView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            )
            setViewTreeLifecycleOwner(this@TiraOverlayService)
            setViewTreeViewModelStoreOwner(this@TiraOverlayService)
            setViewTreeSavedStateRegistryOwner(this@TiraOverlayService)
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)

            setContent {
                val settings by container.settingsRepository.settingsFlow.collectAsState(initial = IslandSettings())
                val installedApps by container.installedAppsRepository.installedApps.collectAsState()
                val music by container.mediaRepository.musicState.collectAsState()
                val banner by container.mediaRepository.latestNotification.collectAsState()
                val battery by container.systemTelemetryRepository.batteryState.collectAsState()
                val system by container.systemTelemetryRepository.systemState.collectAsState()
                val network by container.systemTelemetryRepository.networkState.collectAsState()
                val tools by container.toolsManager.toolsState.collectAsState()
                val isExpanded by isExpandedFlow.collectAsState()
                val activeSection by activeSectionFlow.collectAsState()
                val screenWidthDp by screenWidthDpFlow.collectAsState()

                val pinnedApps = settings.pinnedPackages.mapNotNull { pkg ->
                    installedApps.firstOrNull { it.packageName == pkg }
                }
                val detectedGames = installedApps.filter { it.isGame }

                val callbacks = IslandCallbacks(
                    onToggleExpand = {
                        if (isExpandedFlow.value) collapseIsland() else expandIsland()
                    },
                    onCollapse = { collapseIsland() },
                    onSelectSection = { section ->
                        activeSectionFlow.value = section
                        restartAutoCollapseTimer()
                    },
                    onLaunchApp = { pkg ->
                        container.installedAppsRepository.launchApp(pkg).onFailure {
                            Toast.makeText(this@TiraOverlayService, getString(R.string.error_app_launch_failed), Toast.LENGTH_SHORT).show()
                        }
                        collapseIsland()
                    },
                    onOpenControlApp = { section ->
                        collapseIsland()
                        val openIntent = Intent(this@TiraOverlayService, MainActivity::class.java).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                            putExtra(EXTRA_TARGET_SECTION, section.name)
                        }
                        runCatching { startActivity(openIntent) }
                    },
                    onMusicPlayPause = {
                        container.mediaRepository.togglePlayPause()
                        restartAutoCollapseTimer()
                    },
                    onMusicNext = {
                        container.mediaRepository.skipNext()
                        restartAutoCollapseTimer()
                    },
                    onMusicPrev = {
                        container.mediaRepository.skipPrevious()
                        restartAutoCollapseTimer()
                    },
                    onMusicSeek = { pos ->
                        container.mediaRepository.seekTo(pos)
                        restartAutoCollapseTimer()
                    },
                    onRequestNotificationListener = {
                        collapseIsland()
                        PermissionHelper.openNotificationListenerSettings(this@TiraOverlayService).onFailure {
                            Toast.makeText(this@TiraOverlayService, getString(R.string.error_settings_open_failed), Toast.LENGTH_SHORT).show()
                        }
                    },
                    onClearAppCache = {
                        val freedKb = container.systemTelemetryRepository.clearAppCache()
                        Toast.makeText(this@TiraOverlayService, "Очищено $freedKb КБ", Toast.LENGTH_SHORT).show()
                        restartAutoCollapseTimer()
                    },
                    onToggleGameTurbo = { enabled ->
                        serviceScope.launch {
                            container.gameTurboManager.setGameTurboEnabled(enabled, settings.gameTurboDnd)
                        }
                        restartAutoCollapseTimer()
                    },
                    onToggleGameTurboDnd = { enabled ->
                        serviceScope.launch {
                            container.settingsRepository.updateSettings { it.copy(gameTurboDnd = enabled) }
                        }
                        restartAutoCollapseTimer()
                    },
                    onToggleGameTurboKeepScreen = { enabled ->
                        serviceScope.launch {
                            container.settingsRepository.updateSettings { it.copy(gameTurboKeepScreenOn = enabled) }
                        }
                        restartAutoCollapseTimer()
                    },
                    onToggleGameTurboHud = { enabled ->
                        serviceScope.launch {
                            container.settingsRepository.updateSettings { it.copy(gameTurboCompactHud = enabled) }
                        }
                        restartAutoCollapseTimer()
                    },
                    onOpenDndSettings = {
                        collapseIsland()
                        PermissionHelper.openDndPolicySettings(this@TiraOverlayService)
                    },
                    onOpenInternetPanel = {
                        collapseIsland()
                        PermissionHelper.openInternetPanel(this@TiraOverlayService).onFailure {
                            Toast.makeText(this@TiraOverlayService, getString(R.string.error_settings_open_failed), Toast.LENGTH_SHORT).show()
                        }
                    },
                    onTimerPreset = { sec ->
                        container.toolsManager.setTimerPreset(sec)
                        restartAutoCollapseTimer()
                    },
                    onTimerAddSeconds = { delta ->
                        container.toolsManager.addTimerSeconds(delta)
                        restartAutoCollapseTimer()
                    },
                    onTimerToggle = {
                        container.toolsManager.toggleTimer()
                        restartAutoCollapseTimer()
                    },
                    onTimerReset = {
                        container.toolsManager.resetTimer()
                        restartAutoCollapseTimer()
                    },
                    onStopwatchToggle = {
                        container.toolsManager.toggleStopwatch()
                        restartAutoCollapseTimer()
                    },
                    onStopwatchLap = {
                        container.toolsManager.recordStopwatchLap()
                        restartAutoCollapseTimer()
                    },
                    onStopwatchReset = {
                        container.toolsManager.resetStopwatch()
                        restartAutoCollapseTimer()
                    },
                    onCalcKey = { key ->
                        container.toolsManager.onCalcKey(key)
                        restartAutoCollapseTimer()
                    },
                    onToggleFlashlight = {
                        container.toolsManager.toggleFlashlight()
                        restartAutoCollapseTimer()
                    },
                    onSelectAccent = { accent ->
                        serviceScope.launch {
                            container.settingsRepository.updateSettings { it.copy(accent = accent) }
                        }
                        restartAutoCollapseTimer()
                    },
                    onSelectAnimStyle = { style ->
                        serviceScope.launch {
                            container.settingsRepository.updateSettings { it.copy(animStyle = style) }
                        }
                        restartAutoCollapseTimer()
                    },
                    onAdjustWidthDp = { delta ->
                        serviceScope.launch {
                            container.settingsRepository.updateSettings {
                                it.copy(collapsedWidthDp = (it.collapsedWidthDp + delta).coerceIn(112, 260))
                            }
                        }
                        restartAutoCollapseTimer()
                    },
                    onAdjustTopOffsetDp = { delta ->
                        serviceScope.launch {
                            container.settingsRepository.updateSettings {
                                it.copy(topOffsetDp = (it.topOffsetDp + delta).coerceIn(0, 96))
                            }
                        }
                        restartAutoCollapseTimer()
                    },
                    onStopOverlay = {
                        serviceScope.launch {
                            container.settingsRepository.setOverlayEnabled(false)
                            stopSelf()
                        }
                    },
                    onDismissBanner = {
                        container.mediaRepository.dismissNotificationBanner()
                    },
                )

                TiraTheme(accent = settings.accent) {
                    Box(
                        modifier = Modifier
                            .widthIn(max = (screenWidthDp - 8).coerceAtLeast(280).dp)
                            .padding(horizontal = 4.dp, vertical = 4.dp),
                        contentAlignment = Alignment.TopCenter,
                    ) {
                        DynamicIslandHost(
                            isExpanded = isExpanded,
                            activeSection = activeSection,
                            settings = settings,
                            pinnedApps = pinnedApps,
                            detectedGames = detectedGames,
                            music = music,
                            battery = battery,
                            system = system,
                            network = network,
                            tools = tools,
                            banner = banner,
                            callbacks = callbacks,
                        )
                    }
                }
            }
        }

        wrapper.addView(composeView)
        wrapper.addOnAttachStateChangeListener(object : android.view.View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: android.view.View) {
                updateWindowParamsForSettings(currentSettingsSnapshot)
            }
            override fun onViewDetachedFromWindow(v: android.view.View) = Unit
        })
        rootContainer = wrapper

        runCatching {
            windowManager.addView(wrapper, params)
            _isOverlayAttached.value = true
        }.onFailure { error ->
            Log.e(TAG, "Failed to add overlay view", error)
            _lastError.value = error.localizedMessage ?: getString(R.string.error_overlay_permission)
            _isOverlayAttached.value = false
            rootContainer = null
            Toast.makeText(this, getString(R.string.error_overlay_permission), Toast.LENGTH_LONG).show()
            serviceScope.launch {
                container.settingsRepository.setOverlayEnabled(false)
                stopSelf()
            }
        }
    }

    private fun observeSettingsForLayout() {
        val app = application as? TiraApplication ?: return
        serviceScope.launch {
            combine(
                app.container.settingsRepository.settingsFlow,
                isExpandedFlow,
            ) { settings, _ -> settings }.collect { settings ->
                currentSettingsSnapshot = settings
                updateWindowParamsForSettings(settings)
            }
        }
    }

    private fun updateWindowParamsForSettings(settings: IslandSettings) {
        val view = rootContainer ?: return
        val params = layoutParams ?: return

        val maxHorizontalPx = dpToPx(((screenWidthDpFlow.value / 2) - 48).coerceAtLeast(24))
        val targetX = dpToPx(settings.horizontalOffsetDp).coerceIn(-maxHorizontalPx, maxHorizontalPx)
        val targetY = dpToPx(settings.topOffsetDp)

        val baseFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH

        val desiredFlags = if (settings.gameTurboActive && settings.gameTurboKeepScreenOn) {
            baseFlags or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        } else {
            baseFlags
        }

        if (params.x != targetX || params.y != targetY || params.flags != desiredFlags) {
            params.x = targetX
            params.y = targetY
            params.flags = desiredFlags
            if (view.isAttachedToWindow) {
                runCatching {
                    windowManager.updateViewLayout(view, params)
                }
            }
        }
    }

    private fun expandIsland() {
        isExpandedFlow.value = true
        restartAutoCollapseTimer()
    }

    private fun collapseIsland() {
        autoCollapseJob?.cancel()
        isExpandedFlow.value = false
    }

    private fun restartAutoCollapseTimer() {
        autoCollapseJob?.cancel()
        val timeout = currentSettingsSnapshot.autoCollapseSeconds
        if (!isExpandedFlow.value || timeout <= 0) return
        autoCollapseJob = serviceScope.launch {
            delay(timeout * 1000L)
            isExpandedFlow.value = false
        }
    }

    private fun dpToPx(dp: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            dp.toFloat(),
            resources.displayMetrics,
        ).roundToInt()
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.overlay_service_channel_name),
            NotificationManager.IMPORTANCE_LOW,
        ).apply {
            description = getString(R.string.overlay_service_channel_desc)
            setShowBadge(false)
        }
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(channel)
    }

    private fun buildForegroundNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        val openPending = PendingIntent.getActivity(
            this,
            10,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        val stopIntent = Intent(this, TiraOverlayService::class.java).apply {
            action = ACTION_STOP_OVERLAY
        }
        val stopPending = PendingIntent.getService(
            this,
            11,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_tira_notif)
            .setContentTitle(getString(R.string.overlay_notification_title))
            .setContentText(getString(R.string.overlay_notification_text))
            .setContentIntent(openPending)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(0, getString(R.string.overlay_action_open), openPending)
            .addAction(0, getString(R.string.overlay_action_stop), stopPending)
            .build()
    }

    override fun onDestroy() {
        _isRunning.value = false
        _isOverlayAttached.value = false
        autoCollapseJob?.cancel()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)

        rootContainer?.let { view ->
            runCatching { windowManager.removeViewImmediate(view) }
        }
        rootContainer = null
        store.clear()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val TAG = "TiraOverlayService"
        const val CHANNEL_ID = "tira_overlay_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_STOP_OVERLAY = "com.example.action.STOP_OVERLAY"
        const val EXTRA_TARGET_SECTION = "extra_target_section"

        private val _isRunning = MutableStateFlow(false)
        val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

        private val _isOverlayAttached = MutableStateFlow(false)
        val isOverlayAttached: StateFlow<Boolean> = _isOverlayAttached.asStateFlow()

        private val _lastError = MutableStateFlow<String?>(null)
        val lastError: StateFlow<String?> = _lastError.asStateFlow()

        fun start(context: Context): Result<Unit> = runCatching {
            val intent = Intent(context, TiraOverlayService::class.java)
            context.startForegroundService(intent)
            Unit
        }.onFailure { error ->
            Log.e(TAG, "startForegroundService failed", error)
            _lastError.value = error.localizedMessage ?: "Не удалось запустить службу наложения"
        }

        fun stop(context: Context) {
            val intent = Intent(context, TiraOverlayService::class.java)
            context.stopService(intent)
        }
    }
}
