package com.example.service

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.example.TiraApplication

class TiraNotificationListenerService : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        (application as? TiraApplication)?.container?.mediaRepository?.refreshActiveSessions()
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        (application as? TiraApplication)?.container?.mediaRepository?.refreshActiveSessions()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        val app = application as? TiraApplication ?: return
        val mediaRepo = app.container.mediaRepository

        mediaRepo.refreshActiveSessions()

        val notification = sbn.notification ?: return
        if ((notification.flags and Notification.FLAG_ONGOING_EVENT) != 0) return

        val extras = notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        if (title.isNotEmpty() || text.isNotEmpty()) {
            mediaRepo.onNotificationPosted(sbn.packageName, title, text)
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        (application as? TiraApplication)?.container?.mediaRepository?.refreshActiveSessions()
    }
}
